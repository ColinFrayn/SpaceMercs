﻿namespace SpaceMercs.Dialogs {
  partial class MissionView {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if (disposing && (components != null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.glMissionView = new OpenTK.GLControl();
      this.menuStrip1 = new System.Windows.Forms.MenuStrip();
      this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.saveGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.loadGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.exitGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.missionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.abandonMissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.labelsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.healthBarsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.travelDistanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.movementPathToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.viewEffectsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.viewDetectionRadiiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.detailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.menuStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // glMissionView
      // 
      this.glMissionView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.glMissionView.BackColor = System.Drawing.Color.Black;
      this.glMissionView.Location = new System.Drawing.Point(-1, 27);
      this.glMissionView.Name = "glMissionView";
      this.glMissionView.Size = new System.Drawing.Size(693, 501);
      this.glMissionView.TabIndex = 1;
      this.glMissionView.VSync = false;
      this.glMissionView.Paint += new System.Windows.Forms.PaintEventHandler(this.glMissionView_Paint);
      this.glMissionView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.glMissionView_KeyUp);
      this.glMissionView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.glMissionView_DoubleClick);
      this.glMissionView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.glMissionView_MouseDown);
      this.glMissionView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.glMissionView_MouseMove);
      this.glMissionView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.glMissionView_MouseUp);
      this.glMissionView.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.glMissionView_MouseWheel);
      this.glMissionView.Resize += new System.EventHandler(this.glMissionView_Resize);
      // 
      // menuStrip1
      // 
      this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem,
            this.missionToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.detailsToolStripMenuItem});
      this.menuStrip1.Location = new System.Drawing.Point(0, 0);
      this.menuStrip1.Name = "menuStrip1";
      this.menuStrip1.Size = new System.Drawing.Size(692, 24);
      this.menuStrip1.TabIndex = 2;
      this.menuStrip1.Text = "menuStrip1";
      // 
      // gameToolStripMenuItem
      // 
      this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveGameToolStripMenuItem,
            this.loadGameToolStripMenuItem,
            this.exitGameToolStripMenuItem});
      this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
      this.gameToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
      this.gameToolStripMenuItem.Text = "&Game";
      // 
      // saveGameToolStripMenuItem
      // 
      this.saveGameToolStripMenuItem.Name = "saveGameToolStripMenuItem";
      this.saveGameToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
      this.saveGameToolStripMenuItem.Text = "&Save";
      this.saveGameToolStripMenuItem.Click += new System.EventHandler(this.saveGameToolStripMenuItem_Click);
      // 
      // loadGameToolStripMenuItem
      // 
      this.loadGameToolStripMenuItem.Name = "loadGameToolStripMenuItem";
      this.loadGameToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
      this.loadGameToolStripMenuItem.Text = "&Load";
      this.loadGameToolStripMenuItem.Click += new System.EventHandler(this.loadGameToolStripMenuItem_Click);
      // 
      // exitGameToolStripMenuItem
      // 
      this.exitGameToolStripMenuItem.Name = "exitGameToolStripMenuItem";
      this.exitGameToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
      this.exitGameToolStripMenuItem.Text = "&Exit";
      this.exitGameToolStripMenuItem.Click += new System.EventHandler(this.exitGameToolStripMenuItem_Click);
      // 
      // missionToolStripMenuItem
      // 
      this.missionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abandonMissionToolStripMenuItem});
      this.missionToolStripMenuItem.Name = "missionToolStripMenuItem";
      this.missionToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
      this.missionToolStripMenuItem.Text = "&Mission";
      // 
      // abandonMissionToolStripMenuItem
      // 
      this.abandonMissionToolStripMenuItem.Name = "abandonMissionToolStripMenuItem";
      this.abandonMissionToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
      this.abandonMissionToolStripMenuItem.Text = "&Abandon";
      this.abandonMissionToolStripMenuItem.Click += new System.EventHandler(this.abandonMissionToolStripMenuItem_Click);
      // 
      // viewToolStripMenuItem
      // 
      this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelsToolStripMenuItem,
            this.healthBarsToolStripMenuItem,
            this.travelDistanceToolStripMenuItem,
            this.movementPathToolStripMenuItem,
            this.viewEffectsToolStripMenuItem,
            this.viewDetectionRadiiToolStripMenuItem});
      this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
      this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
      this.viewToolStripMenuItem.Text = "&View";
      // 
      // labelsToolStripMenuItem
      // 
      this.labelsToolStripMenuItem.Name = "labelsToolStripMenuItem";
      this.labelsToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
      this.labelsToolStripMenuItem.Text = "&Labels";
      this.labelsToolStripMenuItem.Click += new System.EventHandler(this.labelsToolStripMenuItem_Click);
      // 
      // healthBarsToolStripMenuItem
      // 
      this.healthBarsToolStripMenuItem.Name = "healthBarsToolStripMenuItem";
      this.healthBarsToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
      this.healthBarsToolStripMenuItem.Text = "&Stat Bars";
      this.healthBarsToolStripMenuItem.Click += new System.EventHandler(this.healthBarsToolStripMenuItem_Click);
      // 
      // travelDistanceToolStripMenuItem
      // 
      this.travelDistanceToolStripMenuItem.Name = "travelDistanceToolStripMenuItem";
      this.travelDistanceToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
      this.travelDistanceToolStripMenuItem.Text = "&Travel Distance";
      this.travelDistanceToolStripMenuItem.Click += new System.EventHandler(this.travelDistanceToolStripMenuItem_Click);
      // 
      // movementPathToolStripMenuItem
      // 
      this.movementPathToolStripMenuItem.Name = "movementPathToolStripMenuItem";
      this.movementPathToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
      this.movementPathToolStripMenuItem.Text = "&Movement Path";
      this.movementPathToolStripMenuItem.Click += new System.EventHandler(this.movementPathToolStripMenuItem_Click);
      // 
      // viewEffectsToolStripMenuItem
      // 
      this.viewEffectsToolStripMenuItem.Name = "viewEffectsToolStripMenuItem";
      this.viewEffectsToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
      this.viewEffectsToolStripMenuItem.Text = "View &Effects";
      this.viewEffectsToolStripMenuItem.Click += new System.EventHandler(this.viewEffectsToolStripMenuItem_Click);
      // 
      // viewDetectionRadiiToolStripMenuItem
      // 
      this.viewDetectionRadiiToolStripMenuItem.Name = "viewDetectionRadiiToolStripMenuItem";
      this.viewDetectionRadiiToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
      this.viewDetectionRadiiToolStripMenuItem.Text = "View &Detection Radii";
      this.viewDetectionRadiiToolStripMenuItem.Click += new System.EventHandler(this.viewDetectionRadiiToolStripMenuItem_Click);
      // 
      // detailsToolStripMenuItem
      // 
      this.detailsToolStripMenuItem.Name = "detailsToolStripMenuItem";
      this.detailsToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
      this.detailsToolStripMenuItem.Text = "&Details";
      this.detailsToolStripMenuItem.Click += new System.EventHandler(this.detailsToolStripMenuItem_Click);
      // 
      // MissionView
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(692, 527);
      this.Controls.Add(this.glMissionView);
      this.Controls.Add(this.menuStrip1);
      this.MainMenuStrip = this.menuStrip1;
      this.Name = "MissionView";
      this.Text = "MissionView";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MissionView_FormClosing);
      this.Load += new System.EventHandler(this.MissionView_Load);
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MissionView_KeyDown);
      this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.glMissionView_KeyUp);
      this.menuStrip1.ResumeLayout(false);
      this.menuStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private OpenTK.GLControl glMissionView;
    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem saveGameToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem loadGameToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem exitGameToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem missionToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem abandonMissionToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem labelsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem healthBarsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem travelDistanceToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem movementPathToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem viewEffectsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem viewDetectionRadiiToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem detailsToolStripMenuItem;
  }
}
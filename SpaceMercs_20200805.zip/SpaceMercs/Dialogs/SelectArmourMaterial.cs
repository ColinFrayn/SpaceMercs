﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;

namespace SpaceMercs.Dialogs {
  partial class SelectArmourMaterial : Form {
    private readonly Dictionary<MaterialType, int> BaseMats;
    private readonly Team PlayerTeam;
    private readonly ArmourType ThisType;
    public MaterialType SelectedMat { get; private set; }

    public SelectArmourMaterial(Dictionary<MaterialType,int> mats, ArmourType tp, Team pt) {
      BaseMats = new Dictionary<MaterialType, int>(mats);
      PlayerTeam = pt;
      ThisType = tp;

      InitializeComponent();
      lbArmourType.Text = tp.Name;
      cbMaterialType.Items.Clear();
      foreach (MaterialType mt in StaticData.Materials.Where(m => m.IsArmourMaterial)) {
        int tot = ThisType.Size;
        if (BaseMats.ContainsKey(mt)) tot += BaseMats[mt];
        if (PlayerTeam.CountMaterial(mt) >= tot) {
          cbMaterialType.Items.Add(mt.Name);
        }
      }
      if (cbMaterialType.Items.Count == 0) {
        cbMaterialType.Items.Add("None Available");
        btSelect.Enabled = false;
      }
      SetValues();
    }

    private void SetValues() {
      // Get selected material
      SelectedMat = StaticData.GetMaterialTypeByName((string)cbMaterialType.SelectedItem);
      if (SelectedMat == null) {
        lbArmour.Visible = false;
        lbMass.Visible = false;
        lbValue.Visible = false;
        lbDiff.Visible = false;
        lbArmourLabel.Visible = false;
        lbMassLabel.Visible = false;
        lbValueLabel.Visible = false;
        lbDiffLabel.Visible = false;
        lbProtection.Visible = false;
        return;
      }
      lbArmour.Visible = true;
      lbArmour.Text = SelectedMat.ArmourMod.ToString();
      lbMass.Visible = true;
      lbMass.Text = SelectedMat.MassMod.ToString();
      lbValue.Visible = true;
      lbValue.Text = SelectedMat.CostMod.ToString();
      lbDiff.Visible = true;
      lbDiff.Text = (-SelectedMat.ConstructionChanceModifier).ToString("N1") + "%";
      lbArmourLabel.Visible = true;
      lbMassLabel.Visible = true;
      lbValueLabel.Visible = true;
      lbDiffLabel.Visible = true;
      lbProtection.Visible = true;
      lbProtection.Items.Clear();
      foreach (WeaponType.DamageType dt in SelectedMat.BonusArmour.Keys) {
        lbProtection.Items.Add(dt.ToString() + " : " + SelectedMat.BonusArmour[dt]);
      }
    }

    private void btCancel_Click(object sender, EventArgs e) {
      SelectedMat = null;
      this.Close();
    }

    private void btSelect_Click(object sender, EventArgs e) {
      this.Close();
    }

    private void cbMaterialType_SelectedIndexChanged(object sender, EventArgs e) {
      SetValues();
    }
  }
}

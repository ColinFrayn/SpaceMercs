﻿namespace SpaceMercs.Dialogs {
  partial class MapView {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if (disposing && (components != null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.glMapView = new OpenTK.GLControl();
      this.menuStrip1 = new System.Windows.Forms.MenuStrip();
      this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.showLabelsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.showMapGridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.fadeUnvisitedStarsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.showRangeCirclesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.showTradeRoutesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.showFlagsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.showColoniesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.shipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.teamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.colonyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.racesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.menuStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // glMapView
      // 
      this.glMapView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.glMapView.BackColor = System.Drawing.Color.Black;
      this.glMapView.Location = new System.Drawing.Point(-1, 26);
      this.glMapView.Name = "glMapView";
      this.glMapView.Size = new System.Drawing.Size(727, 485);
      this.glMapView.TabIndex = 0;
      this.glMapView.VSync = false;
      this.glMapView.Paint += new System.Windows.Forms.PaintEventHandler(this.glMapView_Paint);
      this.glMapView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.glMapView_KeyUp);
      this.glMapView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.glMapView_DoubleClick);
      this.glMapView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.glMapView_MouseDown);
      this.glMapView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.glMapView_MouseMove);
      this.glMapView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.glMapView_MouseUp);
      this.glMapView.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.glMapView_MouseWheel);
      this.glMapView.Resize += new System.EventHandler(this.glMapView_Resize);
      // 
      // menuStrip1
      // 
      this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.optionsToolStripMenuItem,
            this.viewToolStripMenuItem});
      this.menuStrip1.Location = new System.Drawing.Point(0, 0);
      this.menuStrip1.Name = "menuStrip1";
      this.menuStrip1.Size = new System.Drawing.Size(726, 24);
      this.menuStrip1.TabIndex = 1;
      this.menuStrip1.Text = "menuStrip1";
      // 
      // fileToolStripMenuItem
      // 
      this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.toolStripSeparator1,
            this.loadToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
      this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
      this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
      this.fileToolStripMenuItem.Text = "&File";
      // 
      // newToolStripMenuItem
      // 
      this.newToolStripMenuItem.Name = "newToolStripMenuItem";
      this.newToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
      this.newToolStripMenuItem.Text = "&New";
      this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(97, 6);
      // 
      // loadToolStripMenuItem
      // 
      this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
      this.loadToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
      this.loadToolStripMenuItem.Text = "&Load";
      this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
      // 
      // saveToolStripMenuItem
      // 
      this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
      this.saveToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
      this.saveToolStripMenuItem.Text = "&Save";
      this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(97, 6);
      // 
      // exitToolStripMenuItem
      // 
      this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
      this.exitToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
      this.exitToolStripMenuItem.Text = "&Exit";
      this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
      // 
      // helpToolStripMenuItem
      // 
      this.helpToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
      this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
      this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
      this.helpToolStripMenuItem.Text = "&Help";
      // 
      // aboutToolStripMenuItem
      // 
      this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
      this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
      this.aboutToolStripMenuItem.Text = "&About";
      this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
      // 
      // optionsToolStripMenuItem
      // 
      this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showLabelsToolStripMenuItem,
            this.showMapGridToolStripMenuItem,
            this.fadeUnvisitedStarsToolStripMenuItem,
            this.showRangeCirclesToolStripMenuItem,
            this.showTradeRoutesToolStripMenuItem,
            this.showFlagsToolStripMenuItem,
            this.showColoniesToolStripMenuItem});
      this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
      this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
      this.optionsToolStripMenuItem.Text = "&Options";
      // 
      // showLabelsToolStripMenuItem
      // 
      this.showLabelsToolStripMenuItem.Name = "showLabelsToolStripMenuItem";
      this.showLabelsToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
      this.showLabelsToolStripMenuItem.Text = "Show &Labels";
      this.showLabelsToolStripMenuItem.Click += new System.EventHandler(this.showLabelsToolStripMenuItem_Click);
      // 
      // showMapGridToolStripMenuItem
      // 
      this.showMapGridToolStripMenuItem.Name = "showMapGridToolStripMenuItem";
      this.showMapGridToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
      this.showMapGridToolStripMenuItem.Text = "Show Map &Grid";
      this.showMapGridToolStripMenuItem.Click += new System.EventHandler(this.showMapGridToolStripMenuItem_Click);
      // 
      // fadeUnvisitedStarsToolStripMenuItem
      // 
      this.fadeUnvisitedStarsToolStripMenuItem.Name = "fadeUnvisitedStarsToolStripMenuItem";
      this.fadeUnvisitedStarsToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
      this.fadeUnvisitedStarsToolStripMenuItem.Text = "Fade Un&visited Stars";
      this.fadeUnvisitedStarsToolStripMenuItem.Click += new System.EventHandler(this.fadeUnvisitedStarsToolStripMenuItem_Click);
      // 
      // showRangeCirclesToolStripMenuItem
      // 
      this.showRangeCirclesToolStripMenuItem.Name = "showRangeCirclesToolStripMenuItem";
      this.showRangeCirclesToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
      this.showRangeCirclesToolStripMenuItem.Text = "Show &Range Circles";
      this.showRangeCirclesToolStripMenuItem.Click += new System.EventHandler(this.showRangeCirclesToolStripMenuItem_Click);
      // 
      // showTradeRoutesToolStripMenuItem
      // 
      this.showTradeRoutesToolStripMenuItem.Name = "showTradeRoutesToolStripMenuItem";
      this.showTradeRoutesToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
      this.showTradeRoutesToolStripMenuItem.Text = "Show Tr&ade Routes";
      this.showTradeRoutesToolStripMenuItem.Click += new System.EventHandler(this.showTradeRoutesToolStripMenuItem_Click);
      // 
      // showFlagsToolStripMenuItem
      // 
      this.showFlagsToolStripMenuItem.Name = "showFlagsToolStripMenuItem";
      this.showFlagsToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
      this.showFlagsToolStripMenuItem.Text = "Show &Flags";
      this.showFlagsToolStripMenuItem.Click += new System.EventHandler(this.showFlagsToolStripMenuItem_Click);
      // 
      // showColoniesToolStripMenuItem
      // 
      this.showColoniesToolStripMenuItem.Name = "showColoniesToolStripMenuItem";
      this.showColoniesToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
      this.showColoniesToolStripMenuItem.Text = "Show &Colonies";
      this.showColoniesToolStripMenuItem.Click += new System.EventHandler(this.showColoniesToolStripMenuItem_Click);
      // 
      // viewToolStripMenuItem
      // 
      this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colonyToolStripMenuItem,
            this.racesToolStripMenuItem,
            this.shipToolStripMenuItem,
            this.teamToolStripMenuItem});
      this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
      this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
      this.viewToolStripMenuItem.Text = "&View";
      // 
      // shipToolStripMenuItem
      // 
      this.shipToolStripMenuItem.Name = "shipToolStripMenuItem";
      this.shipToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.shipToolStripMenuItem.Text = "&Ship";
      this.shipToolStripMenuItem.Click += new System.EventHandler(this.shipToolStripMenuItem_Click);
      // 
      // teamToolStripMenuItem
      // 
      this.teamToolStripMenuItem.Name = "teamToolStripMenuItem";
      this.teamToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.teamToolStripMenuItem.Text = "&Team";
      this.teamToolStripMenuItem.Click += new System.EventHandler(this.teamToolStripMenuItem_Click);
      // 
      // colonyToolStripMenuItem
      // 
      this.colonyToolStripMenuItem.Name = "colonyToolStripMenuItem";
      this.colonyToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.colonyToolStripMenuItem.Text = "&Colony";
      this.colonyToolStripMenuItem.Click += new System.EventHandler(this.colonyToolStripMenuItem_Click);
      // 
      // racesToolStripMenuItem
      // 
      this.racesToolStripMenuItem.Name = "racesToolStripMenuItem";
      this.racesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.racesToolStripMenuItem.Text = "&Races";
      this.racesToolStripMenuItem.Click += new System.EventHandler(this.racesToolStripMenuItem_Click);
      // 
      // MapView
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(726, 511);
      this.Controls.Add(this.glMapView);
      this.Controls.Add(this.menuStrip1);
      this.Name = "MapView";
      this.Text = "OldOnes 2";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.glMapView_Close);
      this.Load += new System.EventHandler(this.glMapView_Load);
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MapView_KeyDown);
      this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.glMapView_KeyUp);
      this.menuStrip1.ResumeLayout(false);
      this.menuStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private OpenTK.GLControl glMapView;
    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem showLabelsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem showMapGridToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem fadeUnvisitedStarsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem showRangeCirclesToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem showTradeRoutesToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem showFlagsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem showColoniesToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem shipToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem teamToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem colonyToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem racesToolStripMenuItem;
  }
}


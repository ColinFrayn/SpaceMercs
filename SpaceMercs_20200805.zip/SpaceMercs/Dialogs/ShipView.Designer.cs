﻿namespace SpaceMercs.Dialogs {
  partial class ShipView {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if (disposing && (components != null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.glShipView = new OpenTK.GLControl();
      this.SuspendLayout();
      // 
      // glShipView
      // 
      this.glShipView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.glShipView.BackColor = System.Drawing.Color.Black;
      this.glShipView.Location = new System.Drawing.Point(-1, 0);
      this.glShipView.Name = "glShipView";
      this.glShipView.Size = new System.Drawing.Size(693, 528);
      this.glShipView.TabIndex = 1;
      this.glShipView.VSync = false;
      this.glShipView.Paint += new System.Windows.Forms.PaintEventHandler(this.glShipView_Paint);
      this.glShipView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.glShipView_KeyUp);
      this.glShipView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.glShipView_DoubleClick);
      this.glShipView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.glShipView_MouseDown);
      this.glShipView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.glShipView_MouseMove);
      this.glShipView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.glShipView_MouseUp);
      this.glShipView.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.glShipView_MouseWheel);
      this.glShipView.Resize += new System.EventHandler(this.glShipView_Resize);
      // 
      // ShipView
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(692, 527);
      this.Controls.Add(this.glShipView);
      this.Name = "ShipView";
      this.Text = "ShipView";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ShipView_FormClosing);
      this.Load += new System.EventHandler(this.ShipView_Load);
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ShipView_KeyDown);
      this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.glShipView_KeyUp);
      this.ResumeLayout(false);

    }

    #endregion

    private OpenTK.GLControl glShipView;
  }
}
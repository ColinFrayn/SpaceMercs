﻿using System;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Threading;
using System.Text;

namespace SpaceMercs.Dialogs {
  partial class MissionView : Form {
    public enum MissionResult { Victory, Defeat, Evacuated, Aborted, Running, ExitGame };
    public enum SoldierAction { None, Attack, Item };
    public MissionResult Result { get; private set; } // Did we win?
    private bool bLoaded = false;
    private double aspect = 1.0;
    private static Matrix4 perspective;
    private int mx, my, hoverx, hovery;
    private float fMissionViewX, fMissionViewY, fMissionViewZ;
    private readonly Team PlayerTeam;
    private int iStarfieldDL = -1;
    private int iSelectionTexID = -1;
    private TextLabel tlSelect1, tlSelect2, tlSelect3, tlAIRunning;
    static Matrix4 ortho_projection = Matrix4.CreateOrthographicOffCenter(0, 1, 1, 0, -1, 1);
    private GUIPanel gpSelect;
    private GUIIconButton gbZoomTo1, gbZoomTo2, gbZoomTo3, gbZoomTo4, gbWest, gbEast, gbNorth, gbSouth, gbAttack, gbInventory, gbUseItem, gbSearch;
    private GUIButton gbEndTurn, gbTransition, gbEndMission;
    private readonly List<GUIIconButton> lButtons = new List<GUIIconButton>();
    private bool bGUIButtonsInitialised = false;
    private readonly Mission miss;
    private MissionLevel level;
    private readonly Timer clockTick;
    private IEntity SelectedEntity = null;
    private Soldier panelHover = null;
    private bool bDragging = false;
    private int iMiscTexture = -1, iItemTexture = -1;
    private int[,] DistMap;
    private bool[,] TargetMap;
    private bool[,] AoEMap;
    private bool[,] DetectionMap;
    private int AoERadius = -1;
    private List<Point> lCurrentPath;
    private SoldierAction CurrentAction = SoldierAction.None;
    private bool bShowLabels = false, bShowStatBars = false, bShowTravel = false, bShowPath = false, bShowEffects = false, bViewDetection = false;
    public bool ForceClose = false;
    private bool bClosingNow = false;
    private readonly List<VisualEffect> Effects = new List<VisualEffect>();
    private readonly Stopwatch sw = Stopwatch.StartNew();
    private ItemType ActionItem = null;
    private Dispatcher ThisDispatcher = null;
    private bool bAIRunning = false;

    // GUIPanel actions
    public const uint I_OpenDoor = 10001;
    public const uint I_CloseDoor = 10002;
    public const uint I_LockDoor = 10003;
    public const uint I_UnlockDoor = 10004;
    public const uint I_Attack = 10005;
    public const uint I_GoTo = 10006;
    public const uint I_UseItem = 10007;

    // Display parameters
    const float FrameBorder = 0.002f;
    const float ButtonSize = 0.022f;
    const float ButtonGap = 0.004f;

    // CTOR
    public MissionView(Mission m, Team t) {
      PlayerTeam = t;
      miss = m;
      if (m == null) throw new Exception("Starting MissionView with empty mission!");
      miss.SetCurrentMissionView(this);
      bool bInProgress = m.Soldiers.Any();
      if (!bInProgress) miss.Initialise();
      level = miss.GetOrCreateCurrentLevel();
      Result = MissionResult.Running;
      InitializeComponent();
      bool bCanAbort = (miss.Type != Mission.MissionType.RepelBoarders);
      abandonMissionToolStripMenuItem.Enabled = bCanAbort;
      if (!bCanAbort) this.ControlBox = false;

      // Set GUI options
      bShowLabels = t.Mission_ShowLabels;
      labelsToolStripMenuItem.Checked = bShowLabels;
      bShowStatBars = t.Mission_ShowStatBars;
      healthBarsToolStripMenuItem.Checked = bShowStatBars;
      bShowTravel = t.Mission_ShowTravel;
      travelDistanceToolStripMenuItem.Checked = bShowTravel;
      bShowPath = t.Mission_ShowPath;
      movementPathToolStripMenuItem.Checked = bShowPath;
      bShowEffects = t.Mission_ShowEffects;
      viewEffectsToolStripMenuItem.Checked = bShowEffects;
      bViewDetection = t.Mission_ViewDetection;
      viewDetectionRadiiToolStripMenuItem.Checked = bViewDetection;

      // If it's a ship mission then do the starfield;
      if (miss.Type == Mission.MissionType.BoardingParty || miss.Type == Mission.MissionType.RepelBoarders || miss.Type == Mission.MissionType.ShipCombat) SetupStarfield();

      // Choose the soldiers to deploy
      if (!bInProgress) {
        ChooseSoldiers cs = new ChooseSoldiers(PlayerTeam, level.MaximumSoldiers, bCanAbort);
        cs.ShowDialog(this);
        if (cs.Soldiers.Count == 0) {
          Result = MissionResult.Aborted;
          this.Close();
          return;
        }
        foreach (Soldier s in cs.Soldiers) {
          level.AddSoldier(s);
        }
        Random rnd = new Random();
        Const.dtTime.AddHours(1.0 + rnd.NextDouble()); // Time to get to the mission
      }

      // Centre around the first soldier
      CentreView(miss.Soldiers[0]);
      fMissionViewZ = Const.InitialMissionViewZ;
      t.SetCurrentMission(m);

      // Set up maps
      TargetMap = new bool[level.Width, level.Height];
      DistMap = new int[level.Width, level.Height];
      AoEMap = new bool[level.Width, level.Height];
      DetectionMap = new bool[level.Width, level.Height];

      // Add a timer. Not sure why. Maybe for effects.
      clockTick = new Timer();
      clockTick.Tick += new EventHandler(ClockTickProcessor);
      clockTick.Interval = 300;
      clockTick.Start();
    }

    // This is the method to run when the timer is raised.
    private void ClockTickProcessor(Object myObject, EventArgs myEventArgs) {
      if (bLoaded) {
        if (Result != MissionResult.Running) {
          this.Close();
        }

        // --- Resolve clock tick stuff
        // Soldiers auto moving
        List<Soldier> lSoldiers = new List<Soldier>(miss.Soldiers); // In case any die in the middle of the loop
        foreach (Soldier s in lSoldiers) {
          if (s.GoTo == s.Location) s.GoTo = Point.Empty;
          if (s.GoTo != Point.Empty) {
            if (s.TravelRange == 0) { s.GoTo = Point.Empty; continue; } // May happen if something that occurs during movement alters stamina / movement points remaining
            List<Point> path = level.ShortestPath(s, s.Location, s.GoTo, 20, true, 0);
            if (path == null || path.Count == 0) { s.GoTo = Point.Empty; continue; }  // e.g. if some other soldier moved in the way and blocked the route
            if (path[0].X == s.X && path[0].Y == s.Y + 1) MoveSoldier(s, Utils.Direction.North);
            else if (path[0].X == s.X && path[0].Y == s.Y - 1) MoveSoldier(s, Utils.Direction.South);
            else if (path[0].Y == s.Y && path[0].X == s.X - 1) MoveSoldier(s, Utils.Direction.West);
            else if (path[0].Y == s.Y && path[0].X == s.X + 1) MoveSoldier(s, Utils.Direction.East);
            else throw new Exception("Next path point is not adjacent to soldier!");
            if (SelectedEntity == s) { // Soldier is still alive and selected
              if (hoverx >= 0 && hoverx < level.Width && hovery >= 0 && hovery < level.Height && DistMap[hoverx, hovery] > 0) {
                lCurrentPath = level.ShortestPath(SelectedEntity, SelectedEntity.Location, new Point(hoverx, hovery), 20, true);
              }
              else lCurrentPath = null;
            }
          }
        }
      }
      this.Invalidate(true);
    }

    // Display the map, GUI etc.
    private void PrepareScene() {
      glMissionView.MakeCurrent();
      GL.ClearColor(Color.Black);
      GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
      GL.CullFace(CullFaceMode.Back);
      GL.ShadeModel(ShadingModel.Smooth);
      GL.Enable(EnableCap.DepthTest);
      GL.Disable(EnableCap.Blend);
      GL.Hint(HintTarget.PerspectiveCorrectionHint, HintMode.Nicest);
      GL.BlendFunc(BlendingFactorSrc.SrcAlpha, BlendingFactorDest.OneMinusSrcAlpha);
      GL.DepthMask(true);
      GL.Disable(EnableCap.Texture2D);
      GL.Disable(EnableCap.Lighting);
    }
    private void SetupViewport() {
      glMissionView.MakeCurrent();
      int w = glMissionView.Width;
      int h = glMissionView.Height;
      aspect = (double)w / (double)h;
      perspective = Matrix4.CreatePerspectiveFieldOfView(Const.MapViewportAngle, (float)aspect, 0.1f, 1000.0f);
      GL.Viewport(0, 0, w, h);
    }
    private void SetupStarfield() {
      Random rnd = new Random();
      iStarfieldDL = GL.GenLists(1);
      GL.NewList(iStarfieldDL, ListMode.Compile);

      // Generate a lot of stars
      GL.Begin(BeginMode.Points);
      for (int n = 0; n < Const.StarfieldSize; n++) {
        double col = (1.0 - (Math.Pow(rnd.NextDouble() * 8.0, 0.3333) / 2.0)) * 0.9 + 0.1;
        double x = (rnd.NextDouble() * 140.0) - 70.0;
        double y = (rnd.NextDouble() * 90.0) - 45.0;
        if (rnd.Next(20) == 0) GL.PointSize(3.0f);
        else if (rnd.Next(5) == 0) GL.PointSize(2.0f);
        else GL.PointSize(1.0f);
        GL.Color3(col, col, col);
        GL.Vertex3(x, y, -100.0);
      }
      GL.End();
      GL.EndList();
    }
    private void glMissionView_Paint(object sender, PaintEventArgs e) {
      if (!bLoaded) return;
      if (SelectedEntity is Soldier s && s.PlayerTeam == null) SelectedEntity = null; // If player has died, deselect it

      // Set up default OpenGL rendering parameters
      PrepareScene();

      // Set the correct view location & perspective matrix
      GL.MatrixMode(MatrixMode.Projection);
      GL.LoadMatrix(ref perspective);
      GL.MatrixMode(MatrixMode.Modelview);
      GL.LoadIdentity();

      // Draw the starfield (unmoving)
      if (iStarfieldDL != -1) GL.CallList(iStarfieldDL);

      // Shift to the correct location
      GL.Translate(-fMissionViewX, -fMissionViewY, -fMissionViewZ);

      // Display the scene
      level.DisplayMap();

      // Show any indicators on top of the action in the map view
      ShowMapGUIElements();

      // Show creatures/soldiers
      level.DisplayEntities(bShowLabels, bShowStatBars, bShowEffects, fMissionViewZ);

      // Display visual effects
      for (int n = Effects.Count - 1; n >= 0; n--) {
        if (Effects[n].Display(sw)) Effects.RemoveAt(n);
      }

      // Draw any static GUI elements (overlay)
      ShowOverlayGUI();

      // Swap rendered surface to front
      glMissionView.SwapBuffers();

      // if we're displaying visual effects then keep re-painting
      if (Effects.Any()) glMissionView.Invalidate();
    }

    // Keyboard input
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData) {
      // Need to trap keypresses of e.g. Alt, Ctrl key alone, not as modifiers
      glMissionView.Invalidate();
      return base.ProcessCmdKey(ref msg, keyData);
    }
    private void glMissionView_KeyUp(object sender, KeyEventArgs e) {
      if (bAIRunning) return;
      if (e.KeyCode == Keys.Escape) {
        if (CurrentAction == SoldierAction.None) SetSelectedEntity(null);
        CurrentAction = SoldierAction.None;
        ActionItem = null;
        glMissionView.Invalidate();
      }
      if (SelectedEntity != null && SelectedEntity.GetType() == typeof(Soldier) && CurrentAction == SoldierAction.None) {
        Soldier s = SelectedEntity as Soldier;
        if (e.KeyCode == Keys.Down) MoveSoldier(s, Utils.Direction.South);
        if (e.KeyCode == Keys.Up) MoveSoldier(s, Utils.Direction.North);
        if (e.KeyCode == Keys.Left) MoveSoldier(s, Utils.Direction.West);
        if (e.KeyCode == Keys.Right) MoveSoldier(s, Utils.Direction.East);
        if (e.KeyCode == Keys.V && e.Control) ScavengeAll(s);
        if (e.KeyCode == Keys.S && e.Control) SelectedSoldierSearch(null);
        if (e.KeyCode == Keys.P && e.Control) PickUpAll(s);
        if (e.KeyCode == Keys.Space) EndTurn();
        glMissionView.Invalidate();
      }
      if (e.KeyCode == Keys.Tab) TabToNextSoldier();
    }
    private void MissionView_KeyDown(object sender, KeyEventArgs e) {
      glMissionView.Invalidate();
    }

    // Mouse stuff
    private void CheckHover() {
      if (gpSelect != null && gpSelect.Active) return;

      panelHover = null;
      // Check GUIPanel first
      if (gpSelect != null && gpSelect.Active && gpSelect.HoverItem != null) return;

      // Check soldier panels
      float sx = 0.99f - Const.GUIPanelWidth, sy = Const.GUIPanelTop;
      double mxfract = (double)mx / (double)glMissionView.Width;
      double myfract = (double)my / (double)glMissionView.Height;
      if (mxfract >= sx && mxfract <= (sx + Const.GUIPanelWidth)) {
        foreach (Soldier s in miss.Soldiers) {
          float step = s.GetGuiPanelHeight(SelectedEntity == s);
          if (myfract >= sy && myfract <= sy + step) { panelHover = s; return; }
          sy += step + Const.GUIPanelGap;
        }
      }

      // Buttons
      if (gbEndTurn != null && gbEndTurn.IsHover(mx, my)) return;
      if (gbTransition != null && gbTransition.IsHover(mx, my)) return;
      if (gbZoomTo1 != null && gbZoomTo1.IsHover(mx, my)) return;
      if (gbZoomTo2 != null && gbZoomTo1.IsHover(mx, my)) return;
      if (gbZoomTo3 != null && gbZoomTo1.IsHover(mx, my)) return;
      if (gbZoomTo4 != null && gbZoomTo1.IsHover(mx, my)) return;
      if (gbWest != null && gbWest.IsHover(mx, my)) return;
      if (gbEast != null && gbEast.IsHover(mx, my)) return;
      if (gbNorth != null && gbNorth.IsHover(mx, my)) return;
      if (gbSouth != null && gbSouth.IsHover(mx, my)) return;
      if (gbAttack != null && gbAttack.IsHover(mx, my)) return;
      if (gbUseItem != null && gbUseItem.IsHover(mx, my)) return;
      if (gbInventory != null && gbInventory.IsHover(mx, my)) return;
      if (gbSearch != null && gbSearch.IsHover(mx, my)) return;

      // Calculate the position of the mouse pointer
      double mxpos = ((mxfract - 0.5) * (fMissionViewZ / 1.86) * aspect) + fMissionViewX;
      double mypos = ((0.5 - myfract) * (fMissionViewZ / 1.86)) + fMissionViewY;
      int oldhoverx = hoverx;
      int oldhovery = hovery;
      hoverx = (int)mxpos;
      hovery = (int)mypos;
      if (hoverx != oldhoverx || hovery != oldhovery) {
        if (SelectedEntity != null && SelectedEntity is Soldier) {
          if (hoverx >= 0 && hoverx < level.Width && hovery >= 0 && hovery < level.Height && DistMap[hoverx, hovery] > 0) {
            lCurrentPath = level.ShortestPath(SelectedEntity, SelectedEntity.Location, new Point(hoverx, hovery), 20, true);
          }
          else lCurrentPath = null;
        }
        else lCurrentPath = null;
      }
      level.SetHover(hoverx, hovery);
    }
    private void glMissionView_MouseMove(object sender, MouseEventArgs e) {
      if (e.Button == MouseButtons.Left) {
        float fScale = Const.MouseMoveScale * fMissionViewZ / 50.0f;
        if (Control.ModifierKeys == Keys.Control) fScale *= 2.5f;
        else if (Control.ModifierKeys == Keys.Shift) fScale /= 2.5f;
        fMissionViewX -= (float)(e.X - mx) * fScale;
        if (fMissionViewX < 0) fMissionViewX = 0;
        if (fMissionViewX > level.Width) fMissionViewX = level.Width;
        fMissionViewY += (float)(e.Y - my) * fScale;
        if (fMissionViewY < 0) fMissionViewY = 0;
        if (fMissionViewY > level.Height) fMissionViewY = level.Height;
        glMissionView.Invalidate();
        bDragging = true;
      }
      else bDragging = false;
      mx = e.X;
      my = e.Y;
      int oldhoverx = hoverx, oldhovery = hovery;
      CheckHover();
      // Mouse has moved to a different square
      if (hoverx != oldhoverx || hovery != oldhovery) {
        if (hoverx > 0 && hoverx < level.Width - 1 && hovery > 0 && hovery < level.Height - 1 && TargetMap[hoverx, hovery]) {
          if (ActionItem != null) {
            GenerateAoEMap(hoverx, hovery, ActionItem.ItemEffect.Radius, oldhoverx, oldhovery);
          }
          else if (SelectedEntity != null && SelectedEntity is Soldier s && s.EquippedWeapon != null && s.EquippedWeapon.Type.Area > 0) {
            GenerateAoEMap(hoverx, hovery, s.EquippedWeapon.Type.Area, oldhoverx, oldhovery);
          }
        }
      }

      glMissionView.Invalidate();
    }
    private async void glMissionView_MouseUp(object sender, MouseEventArgs e) {
      // Check R-button released
      if (bAIRunning) return;
      Soldier s = null;
      if (SelectedEntity is Soldier) s = (Soldier)SelectedEntity;
      if (e.Button == MouseButtons.Right) {
        if (gpSelect != null && gpSelect.Active) {
          gpSelect.Deactivate();
          int iSelectHover = gpSelect.HoverID;
          // Process GUIPanel selection
          if (s != null && iSelectHover >= 0 && gpSelect.HoverItem.Enabled) {
            if (iSelectHover == I_OpenDoor) {
              level.OpenDoor(gpSelect.ClickX, gpSelect.ClickY);
              SoundEffects.PlaySound("OpenDoor");
              GenerateDistMap(s);
              s.UpdateVisibility(level);
              level.CalculatePlayerVisibility();
              GenerateDetectionMap();
              if (UpdateDetectionForSoldier(s)) {
                MessageBox.Show(this, s.Name + " has been detected by the enemy!");
              }
            }
            if (iSelectHover == I_CloseDoor) {
              if (level.CloseDoor(gpSelect.ClickX, gpSelect.ClickY)) {
                SoundEffects.PlaySound("CloseDoor");
                GenerateDistMap(SelectedEntity as Soldier);
                GenerateDetectionMap();
                s.UpdateVisibility(level);
                level.CalculatePlayerVisibility();
              }
            }
            if (iSelectHover == I_UnlockDoor) {
              // TODO
            }
            if (iSelectHover == I_LockDoor) {
              // TODO
            }
            if (iSelectHover == I_Attack) {
              bool bAttacked = await Task.Run(() => s.AttackLocation(level, gpSelect.ClickX, gpSelect.ClickY, AddNewEffect, glMissionView.Invalidate, PlaySoundThreaded, AnnounceMessage));
              //bool bAttacked = s.AttackLocation(level, gpSelect.ClickX, gpSelect.ClickY, AddNewEffect, glMissionView.Invalidate, PlaySoundThreaded).Result;
              if (bAttacked) {
                if (UpdateDetectionForSoldier(s, Const.FireWeaponExtraDetectionRange) ||
                    UpdateDetectionForLocation(gpSelect.ClickX, gpSelect.ClickY, 0, Const.BaseDetectionRange)) {
                  //MessageBox.Show(this, s.Name + " has been detected by the enemy!");
                }
              }
            }
            if (iSelectHover == I_GoTo) {
              s.GoTo = new Point(gpSelect.ClickX, gpSelect.ClickY);
            }
            if (iSelectHover >= Const.ItemIDBase && iSelectHover < (Const.ItemIDBase + 50000)) {
              // Clicked on a usable item
              ItemType it = StaticData.GetItemTypeById(iSelectHover);
              if (it == null) throw new Exception("Chose unknown ItemType to use");
              ActionItem = it;
              CurrentAction = SoldierAction.Item;
              GenerateTargetMap(s, it.ItemEffect.Range);
              int sy = SelectedEntity.Y;
              int sx = SelectedEntity.X;
              GenerateAoEMap(sx, sy, it.ItemEffect.Radius);
              glMissionView.Invalidate();
            }
          }
        }
      }
      if (e.Button == MouseButtons.Left) {
        if (CurrentAction == SoldierAction.Attack) {
          CurrentAction = SoldierAction.None;
          bool bAttacked = await Task.Run(() => s.AttackLocation(level, hoverx, hovery, AddNewEffect, glMissionView.Invalidate, PlaySoundThreaded, AnnounceMessage));
          //bool bAttacked = s.AttackLocation(level, hoverx, hovery, AddNewEffect, glMissionView.Invalidate, PlaySoundThreaded).Result;
          if (bAttacked) {
            if (UpdateDetectionForSoldier(s, Const.FireWeaponExtraDetectionRange) ||
                UpdateDetectionForLocation(hoverx, hovery, 0, Const.BaseDetectionRange)) {
              //MessageBox.Show(this, s.Name + " has been detected by the enemy!");
            }
          }
        }
        else if (CurrentAction == SoldierAction.Item) {
          if (s.Stamina < s.UseItemCost) {
            MessageBox.Show(this, "You have insufficient Stamina to use Item!");
            return;
          }
          // Firstly, remove the item from the Soldier in question if it's a single use item
          ItemType temp = ActionItem;
          s.UseItem(ActionItem);
          CurrentAction = SoldierAction.None;
          ActionItem = null;
          glMissionView.Invalidate();
          // Now apply the effect
          ApplyItemEffectToMap(s, temp, hoverx, hovery);
          if (UpdateDetectionForLocation(hoverx, hovery, 0, Const.BaseDetectionRange)) {
            //MessageBox.Show(this, s.Name + " has been detected by the enemy!");
          }
        }
        else {
          bool bClicked = false;
          foreach (GUIIconButton bt in lButtons) bClicked |= bt.CaptureClick(mx, my);
          if (gbEndTurn != null) bClicked |= gbEndTurn.CaptureClick(mx, my);
          if (gbTransition != null) bClicked |= gbTransition.CaptureClick(mx, my);
          if (gbEndMission != null) bClicked |= gbEndMission.CaptureClick(mx, my);
          if (!bClicked) {
            if (panelHover != null) SetSelectedEntity(panelHover);
            else if (!bDragging) SetSelectedEntity(level.GetHoverEntity());
          }
        }
      }
      if (SelectedEntity is Soldier) {
        GenerateDistMap(SelectedEntity as Soldier);
        GenerateDetectionMap();
      }
      CheckHover();
      glMissionView.Invalidate();
    }
    private void glMissionView_MouseDown(object sender, MouseEventArgs e) {
      if (e.Button == MouseButtons.Right) {
        if (SelectedEntity != null && (SelectedEntity is Soldier) && !bAIRunning) SetupContextMenu();
      }
      if (e.Button == MouseButtons.Left) {
        // TODO: Left click
      }
    }
    private void glMissionView_DoubleClick(object sender, MouseEventArgs e) {
      if (e.Button == MouseButtons.Left) {
        if (panelHover != null) return;
        foreach (GUIIconButton bt in lButtons) {
          if (bt.IsHover(mx, my)) return;
        }
        if (gbEndTurn.IsHover(mx, my)) return;
        if (gbTransition.IsHover(mx, my)) return;
        if (gbEndMission.IsHover(mx, my)) return;
        Point pt = level.MouseHover;
        if (pt == null) return;
        IEntity he = level.GetHoverEntity();
        if (he != null) {
          using (CreatureView cv = new CreatureView(he, Cursor.Position)) {
            cv.ShowDialog(this);
          }
        }
        else {
          fMissionViewX = pt.X + 0.5f;
          fMissionViewY = pt.Y + 0.5f;
        }
        glMissionView.Invalidate();
      }
    }
    private void glMissionView_MouseWheel(object sender, MouseEventArgs e) {
      float delta = 0.0f;
      if (Control.ModifierKeys == Keys.Control) delta -= e.Delta / 50.0f;
      else if (Control.ModifierKeys == Keys.Shift) delta -= e.Delta / 500.0f;
      else delta -= e.Delta / 150.0f;
      fMissionViewZ += delta;
      if (fMissionViewZ < Const.MinimumMissionViewZ) fMissionViewZ = Const.MinimumMissionViewZ;
      if (fMissionViewZ > Const.MaximumMissionViewZ) fMissionViewZ = Const.MaximumMissionViewZ;
      glMissionView.Invalidate();
    }

    // Admin
    private void MissionView_FormClosing(object sender, FormClosingEventArgs e) {
      if (e.CloseReason == CloseReason.UserClosing && !ForceClose && Result == MissionResult.Running) {
        if (!abandonMissionToolStripMenuItem.Enabled) {
          e.Cancel = true;
          return;
        }
        if (bClosingNow) return;
        bClosingNow = true;
        if (MessageBox.Show(this, "Really quit mission? You will lose all rewards, and the mission will be reset.", "Quit Mission?", MessageBoxButtons.YesNo) == DialogResult.No) {
          e.Cancel = true;
          bClosingNow = false;
          return;
        }
        Result = MissionResult.Evacuated;
      }
      bLoaded = false;
    }
    private void MissionView_Load(object sender, EventArgs e) {
      SetupViewport();
      bLoaded = true;
      ThisDispatcher = Dispatcher.CurrentDispatcher;
      glMissionView.Invalidate();
    }
    private void glMissionView_Resize(object sender, EventArgs e) {
      if (!bLoaded) return;
      SetupViewport();
      glMissionView.Invalidate();
    }
    private void AddNewEffect(VisualEffect.EffectType type, double x, double y, Dictionary<string, object> dict) {
      Effects.Add(new VisualEffect(type, x, y, sw, 1.0, dict));
      glMissionView.Invalidate();
    }

    // Actions
    private void MoveSoldier(Soldier s, Utils.Direction d) {
      if (s.Move(d)) UpdateLevelAfterSoldierMove(s);
    }
    private void UpdateLevelAfterSoldierMove(Soldier s) {
      CheckForTransition();
      if (SelectedEntity is Soldier se) GenerateDistMap(se);
      GenerateDetectionMap();
      // Check if this soldier was detected
      if (DetectionMap[s.X, s.Y]) {
        if (UpdateDetectionForSoldier(s)) {
          MessageBox.Show(this, s.Name + " has been detected by the enemy!");
        }
      }
      CheckForTraps(s);
      foreach (Creature cr in level.Creatures) {
        if (cr.CurrentTarget == s && cr.CanSee(s)) cr.SetTarget(s);   // Make sure creature is following us by setting the target (NOP) and updating the Investigation square with Soldier's current position
      }
    }
    private void CheckForTransition() {
      // Test if all soldiers are now on an entrance/exit square and set up the button if so.
      if (level.CheckAllSoldiersAtEntrance()) {
        gbTransition.Activate();
        if (level.LevelID == 0) gbTransition.UpdateText("Exit Mission");
        else gbTransition.UpdateText("Ascend to Level " + (level.LevelID - 1));
      }
      else if (level.CheckAllSoldiersAtExit()) {
        gbTransition.Activate();
        gbTransition.UpdateText("Descend to Level " + (level.LevelID + 1));
      }
      else gbTransition.Deactivate();
    }
    private void ApplyItemEffectToMap(Soldier s, ItemType it, int px, int py) {
      ItemEffect ie = it.ItemEffect;
      HashSet<IEntity> hsEntities = new HashSet<IEntity>();

      // Play a sound, if there is one
      if (!String.IsNullOrEmpty(ie.SoundEffect)) {
        SoundEffects.PlaySound(ie.SoundEffect);
        Thread.Sleep(500);
      }
      for (int y = (int)Math.Max(py - ie.Radius, 0); y <= (int)Math.Min(py + ie.Radius, level.Height - 1); y++) {
        for (int x = (int)Math.Max(px - ie.Radius, 0); x <= (int)Math.Min(px + ie.Radius, level.Width - 1); x++) {
          if ((x - px) * (x - px) + (y - py) * (y - py) > ie.Radius * ie.Radius) continue;
          IEntity en = level.GetEntityAt(x, y);
          if (en != null && !hsEntities.Contains(en)) {
            hsEntities.Add(en); // Make sure we don't double count e.g. large entities
          }
        }
      }
      foreach (IEntity en in hsEntities) {
        en.ApplyEffectToEntity(s, ie, AddNewEffect);
      }
    }
    private bool CheckForTraps(Soldier s) {
      Trap tr = level.GetTrapAtPoint(s.X, s.Y);
      if (tr == null) return false;

      // Stop auto-move
      s.GoTo = Point.Empty;

      // Trigger the trap
      if (tr.Hidden) {
        MessageBox.Show(this, "You have triggered a hidden trap!");
        tr.Reveal();
      }

      // Generate Damage
      Dictionary<WeaponType.DamageType, double> AllDam = tr.GenerateDamage();
      double TotalDam = s.InflictDamage(AllDam);
      Thread.Sleep(100);
      SoundEffects.PlaySound("Click");
      Thread.Sleep(100);
      SoundEffects.PlaySound("Grunt");
      AddNewEffect(VisualEffect.EffectType.Damage, s.X + 0.5, s.Y + 0.5, new Dictionary<string, object>() { { "Value", TotalDam } });

      return true;
    }
    private bool UpdateDetectionForSoldier(Soldier s, double extraRange = 0.0) {
      if (s == null) return false;
      if (extraRange == 0.0 && !DetectionMap[s.X, s.Y]) return false;
      double baseRange = s.DetectionRange + extraRange;
      return UpdateDetectionForLocation(s.X, s.Y, s.Level, baseRange);
    }
    private bool UpdateDetectionForLocation(int x, int y, int sLevel, double baseRange) {
      if (x < 0 || y < 0 || x >= level.Width || y >= level.Height) return false;
      // Check every nearby creature to see if it can detect this soldier
      HashSet<Creature> hsDetected = new HashSet<Creature>();
      foreach (Creature cr in level.Creatures) {
        if (!cr.IsAlert && !hsDetected.Contains(cr)) {
          double range = baseRange;
          if (sLevel > 0) range += ((cr.Level - sLevel) / 3.0); // sLevel == 0 means no level bonuses to be applied
          // Check range
          double r2 = (x - cr.X) * (x - cr.X) + (y - cr.Y) * (y - cr.Y);
          if (r2 <= (range * range) && cr.CanSee(x, y)) {
            hsDetected.Add(cr);
            cr.Alert();
            cr.SetTargetInvestigation(x, y);
          }
        }
      }
      if (hsDetected.Count == 0) return false;
      foreach (Creature crd in hsDetected) {
        foreach (Creature cr in level.Creatures) {
          if (!cr.IsAlert) {
            int r2 = (crd.X - cr.X) * (crd.X - cr.X) + (crd.Y - cr.Y) * (crd.Y - cr.Y);
            if (r2 <= Const.CreatureAlertWarningDistance * Const.CreatureAlertWarningDistance) {
              if (cr.CanSee(crd)) cr.Alert();
              cr.SetTargetInvestigation(x,y);
            }
          }
        }
      }
      GenerateDetectionMap();
      return true;
    }
    private void ScavengeAll(Soldier s) {
      int sk = s.GetUtilityLevel(Soldier.UtilitySkill.Scavenging);
      if (sk == 0) return;
      Stash st = level.GetStashAtPoint(s.X, s.Y);
      if (st == null) return;
      Dictionary<IItem, int> Scavenged = new Dictionary<IItem, int>();
      Random rand = new Random();
      foreach (IItem it in st.Items()) {
        if (it is Corpse cp && !cp.IsSoldier) {
          // Generate stuff
          for (int n = 0; n < st.GetCount(it); n++) {
            List<IItem> stuff = cp.Scavenge(sk, rand);
            foreach (IItem sc in stuff) {
              s.AddItem(sc);
              if (Scavenged.ContainsKey(sc)) Scavenged[sc]++;
              else Scavenged.Add(sc, 1);
            }
          }
          st.Remove(it);
        }
      }
      StringBuilder sb = new StringBuilder();
      if (!Scavenged.Any()) {
        sb.AppendLine("You found nothing useful");
      }
      else {
        sb.AppendLine("Scavenging Results:");
        foreach (IItem sc in Scavenged.Keys) {
          sb.AppendFormat("{0} [{1}]", sc.Name, Scavenged[sc]);
          sb.AppendLine();
        }
      }
      MessageBox.Show(this, sb.ToString(), "Scavenge Results");
      if (st.Count == 0) level.ReplaceStashAtPosition(s.X, s.Y, null);
    }
    private void PickUpAll(Soldier s) {
      Stash st = level.GetStashAtPoint(s.X, s.Y);
      if (st == null) return;
      int count = 0;
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Objects Picked Up:");
      foreach (IItem it in st.Items()) {
        if (!(it is Corpse)) {
          int num = st.GetCount(it);
          s.AddItem(it, num);
          sb.AppendLine(it.Name + " [" + num + "]");
          st.Remove(it, num);
          count++;
        }
      }
      if (st.Count == 0) level.ReplaceStashAtPosition(s.X, s.Y, null);
      if (count == 0) sb.AppendLine("You found nothing useful");
      MessageBox.Show(this, sb.ToString(), "Objects Received");
    }
    private void TabToNextSoldier() {
      if (SelectedEntity == null || SelectedEntity is Creature) {
        SetSelectedEntity(miss.Soldiers[0]);
        CentreView(miss.Soldiers[0]);
        return;
      }
      else {
        Soldier s = ((Soldier)SelectedEntity);
        for (int n=0; n<miss.Soldiers.Count; n++) {
          if (miss.Soldiers[n] == s) {
            if (n == miss.Soldiers.Count - 1) n = 0;
            else n++;
            SetSelectedEntity(miss.Soldiers[n]);
            CentreView(miss.Soldiers[n]);
            return;
          }
        }
      }
      throw new Exception("Couldn't identify tab soldier");
      }

    // Menu handlers
    private void saveGameToolStripMenuItem_Click(object sender, EventArgs e) {
      Form owner = this.Owner;
      MapView mv = (MapView)owner;
      this.TopMost = false;
      mv.SaveGame();
      this.TopMost = true;
    }
    private void loadGameToolStripMenuItem_Click(object sender, EventArgs e) {
      Form owner = Owner;
      MapView mv = (MapView)owner;
      TopMost = false;
      mv.LoadGame();
      TopMost = true;
    }
    private void exitGameToolStripMenuItem_Click(object sender, EventArgs e) {
      if (MessageBox.Show(this, "Really exit the game? All unsaved progress will be lost", "Exit game", MessageBoxButtons.YesNo) == DialogResult.No) return;
      Result = MissionResult.ExitGame;
      this.Close();
    }
    private void abandonMissionToolStripMenuItem_Click(object sender, EventArgs e) {
      if (MessageBox.Show(this, "Really abandon this mission?", "Abandon mission", MessageBoxButtons.YesNo) == DialogResult.No) return;
      Result = MissionResult.Evacuated;
      this.Close();
    }
    private void detailsToolStripMenuItem_Click(object sender, EventArgs e) {
      string strDesc = miss.GetDescription();
      if (miss.Goal == Mission.MissionGoal.ExploreAll || miss.Goal == Mission.MissionGoal.KillAll || miss.Goal == Mission.MissionGoal.Gather) {
        strDesc += "----------\nProgress:\n";
        for (int n = 0; n < miss.LevelCount; n++) {
          strDesc += "Level " + n + " : ";
          MissionLevel lev = miss.GetLevel(n);
          if (lev == null) strDesc += "Not explored\n";
          else {
            if (miss.Goal == Mission.MissionGoal.ExploreAll) {
              Tuple<int, int> tp = lev.UnexploredTiles;
              int rem = tp.Item1;
              if (rem == 1) strDesc += "1 tile remaining\n";
              else if (rem == 0) strDesc += "Complete\n";
              else strDesc += rem.ToString() + " tiles remaining\n";
            }
            else if (miss.Goal == Mission.MissionGoal.KillAll) {
              int rem = lev.Creatures.Count();
              if (rem == 1) strDesc += "1 enemy remaining\n";
              else if (rem == 0) strDesc += "Complete\n";
              else strDesc += rem.ToString() + " enemies remaining\n";
            }
            else if (miss.Goal == Mission.MissionGoal.Gather) {
              int rem = lev.CountMissionItemsRemaining;
              if (rem == 1) strDesc += "1 item remaining\n";
              else if (rem == 0) strDesc += "Complete\n";
              else strDesc += rem.ToString() + " items remaining\n";
            }
          }
        }
      }
      MessageBox.Show(this, strDesc, "Mission Details");
    }


    // View menu options
    private void labelsToolStripMenuItem_Click(object sender, EventArgs e) {
      bShowLabels = !bShowLabels;
      labelsToolStripMenuItem.Checked = bShowLabels;
      PlayerTeam.Mission_ShowLabels = bShowLabels;
      glMissionView.Invalidate();
    }
    private void healthBarsToolStripMenuItem_Click(object sender, EventArgs e) {
      bShowStatBars = !bShowStatBars;
      healthBarsToolStripMenuItem.Checked = bShowStatBars;
      PlayerTeam.Mission_ShowStatBars = bShowStatBars;
      glMissionView.Invalidate();
    }
    private void travelDistanceToolStripMenuItem_Click(object sender, EventArgs e) {
      bShowTravel = !bShowTravel;
      travelDistanceToolStripMenuItem.Checked = bShowTravel;
      PlayerTeam.Mission_ShowTravel = bShowTravel;
      glMissionView.Invalidate();
    }
    private void movementPathToolStripMenuItem_Click(object sender, EventArgs e) {
      bShowPath = !bShowPath;
      movementPathToolStripMenuItem.Checked = bShowPath;
      PlayerTeam.Mission_ShowPath = bShowPath;
      glMissionView.Invalidate();
    }
    private void viewEffectsToolStripMenuItem_Click(object sender, EventArgs e) {
      bShowEffects = !bShowEffects;
      viewEffectsToolStripMenuItem.Checked = bShowEffects;
      PlayerTeam.Mission_ShowEffects = bShowEffects;
      glMissionView.Invalidate();
    }
    private void viewDetectionRadiiToolStripMenuItem_Click(object sender, EventArgs e) {
      bViewDetection = !bViewDetection;
      viewDetectionRadiiToolStripMenuItem.Checked = bViewDetection;
      PlayerTeam.Mission_ViewDetection = bViewDetection;
      GenerateDetectionMap();
      glMissionView.Invalidate();
    }

    // Show GUI elements in the viewpoint of the map
    private void ShowMapGUIElements() {
      // Mouse hover
      GL.Disable(EnableCap.DepthTest);
      Point pt = level.MouseHover;
      if (pt != Point.Empty && CurrentAction == SoldierAction.None) {
        DrawHoverFrame(pt.X, pt.Y);
      }
      if (SelectedEntity != null) {
        DrawSelectionTile(SelectedEntity.Location.X + SelectedEntity.Size / 2.0, SelectedEntity.Location.Y + SelectedEntity.Size / 2.0, SelectedEntity.Size /* + 0.2 */);
      }

      if (CurrentAction == SoldierAction.Attack) {
        DrawTargetGrid();
        if (TargetMap[pt.X, pt.Y] == true) {
          DrawHoverFrame(pt.X, pt.Y);
          if (SelectedEntity != null && SelectedEntity is Soldier soldier && soldier.EquippedWeapon != null && soldier.EquippedWeapon.Type.Area > 0) DrawAoEGrid();
        }
      }
      else if (CurrentAction == SoldierAction.Item) {
        DrawTargetGrid();
        if (TargetMap[pt.X, pt.Y] == true) {
          DrawHoverFrame(pt.X, pt.Y);
          DrawAoEGrid();
        }
      }
      else {
        if (bShowTravel && SelectedEntity != null && SelectedEntity is Soldier) {
          DrawTravelGrid();
        }
        if (bShowPath && SelectedEntity != null && SelectedEntity is Soldier) {
          if (hoverx >= 0 && hoverx < level.Width && hovery >= 0 && hovery < level.Height && DistMap[hoverx, hovery] > 0) {
            DrawTravelPath();
          }
        }
      }
      if (bViewDetection) level.DrawDetectionMap(DetectionMap);
      if (Const.DEBUG_SHOW_SELECTED_ENTITY_VIS && SelectedEntity != null) level.DrawSelectedEntityVis(SelectedEntity);
      GL.Enable(EnableCap.DepthTest);
    }

    // Show GUI elements in the overlay layer
    private void ShowOverlayGUI() {
      SetupGUITextures();
      InitialiseGUIButtons();
      GL.MatrixMode(MatrixMode.Projection);
      GL.LoadMatrix(ref ortho_projection);
      GL.MatrixMode(MatrixMode.Modelview);
      GL.LoadIdentity();
      GL.Disable(EnableCap.Lighting);
      GL.Disable(EnableCap.DepthTest);

      // Show the selected entity details if it's a creature
      if (SelectedEntity != null && SelectedEntity is Creature) {
        ShowSelectedEntityDetails();
      }

      // Details on the squad
      ShowSoldierPanels();

      // Show the context menu and other buttons
      if (gpSelect != null) gpSelect.Display(mx, my);
      foreach (GUIIconButton bt in lButtons) bt.Display(mx, my);
      if (gbEndTurn != null) gbEndTurn.Display(mx, my);
      if (gbTransition != null) gbTransition.Display(mx, my);
      if (miss.IsComplete) {
        gbEndMission.Activate();
        gbEndMission.SetStipple(level.AlertedEnemies);
        gbEndMission.Display(mx, my);
      }
      else gbEndMission.Deactivate();

      // Warn that AI is running?
      if (bAIRunning) {
        DisplayAILabel();
      }

      GL.Enable(EnableCap.DepthTest);
    }
    private void DisplayAILabel() {
      if (tlAIRunning == null) tlAIRunning = new TextLabel("AI Running");
      GL.PushMatrix();
      GL.Translate(0.5, 0.02, Const.GUILayer);
      GL.Scale(0.06, 0.06, 0.04);
      GL.Color3(0.1, 0.1, 0.1);
      GL.DepthMask(false);
      GL.Begin(BeginMode.Quads);
      GL.Vertex3(-1.8, 0.1, 0.0);
      GL.Vertex3(1.8, 0.1, 0.0);
      GL.Vertex3(1.8, 1.0, 0.0);
      GL.Vertex3(-1.8, 1.0, 0.0);
      GL.End();
      GL.DepthMask(true);
      GL.Color3(1.0, 1.0, 1.0);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlAIRunning.Draw(TextLabel.Alignment.TopMiddle);
      GL.PopMatrix();
    }
    private void ShowSelectedEntityDetails() {
      if (tlSelect1 == null) tlSelect1 = new TextLabel();
      tlSelect1.UpdateText(SelectedEntity.Name);
      if (tlSelect2 == null) tlSelect2 = new TextLabel();
      tlSelect2.UpdateText("Level " + SelectedEntity.Level);
      if (tlSelect3 == null) tlSelect3 = new TextLabel();
      int hp = (int)SelectedEntity.Health;
      if (hp < 1) hp = 1;
      tlSelect3.UpdateText("HP:" + hp + " / " + "St:" + (int)SelectedEntity.Stamina + ((SelectedEntity.MaxShields > 0) ? " / " + "Sh:" + (int)SelectedEntity.Shields : ""));

      // Display the stats for the selected entity
      GL.PushMatrix();
      GL.Translate(0.998, 0.81 - (SelectedEntity.MaxShields > 0 ? 0.0368 : 0.0), Const.GUILayer);
      GL.Scale(0.04, 0.04, 0.04);
      GL.Rotate(180.0, Vector3d.UnitX);
      //tlSelect1.SetAlpha(Const.GUIAlpha);
      tlSelect1.Draw(TextLabel.Alignment.TopRight);
      GL.Translate(0.0, -0.92, 0.0);
      //tlSelect2.SetAlpha(Const.GUIAlpha);
      tlSelect2.Draw(TextLabel.Alignment.TopRight);
      GL.Translate(0.0, -0.92, 0.0);
      //tlSelect3.SetAlpha(Const.GUIAlpha);
      tlSelect3.Draw(TextLabel.Alignment.TopRight);
      GL.PopMatrix();
    }
    private void ShowSoldierPanels() {
      // Show the details of the soldiers
      float sx = 0.99f - Const.GUIPanelWidth, sy = Const.GUIPanelTop;
      IEntity hover = level.GetHoverEntity();
      if (panelHover != null) hover = panelHover;
      for (int sno = 0; sno < miss.Soldiers.Count; sno++) {
        Soldier s = miss.Soldiers[sno];
        float PanelHeight = s.GetGuiPanelHeight(SelectedEntity == s);

        // Place the buttons (Y only, plus on/off if soldier is selected)
        if (sno == 0) gbZoomTo1.ButtonY = sy + FrameBorder;
        if (sno == 1) gbZoomTo2.ButtonY = sy + FrameBorder;
        if (sno == 2) gbZoomTo3.ButtonY = sy + FrameBorder;
        if (sno == 3) gbZoomTo4.ButtonY = sy + FrameBorder;
        if (SelectedEntity == s) {
          gbWest.ButtonY = sy + PanelHeight - (ButtonSize * 2 + ButtonGap * 2);
          gbEast.ButtonY = sy + PanelHeight - (ButtonSize * 2 + ButtonGap * 2);
          gbNorth.ButtonY = sy + PanelHeight - (ButtonSize * 3 + ButtonGap * 3);
          gbSouth.ButtonY = sy + PanelHeight - (ButtonSize + ButtonGap);
          gbAttack.ButtonY = sy + PanelHeight - (ButtonSize * 3 + ButtonGap * 3);
          gbUseItem.ButtonY = sy + PanelHeight - (ButtonSize * 3 + ButtonGap * 3);
          gbInventory.ButtonY = sy + PanelHeight - (ButtonSize * 1.5 + ButtonGap * 1);
          gbSearch.ButtonY = sy + PanelHeight - (ButtonSize * 1.5 + ButtonGap * 1);
          if (bAIRunning) gbInventory.Deactivate();
          else gbInventory.Activate();
          if (s.Stamina < s.AttackCost || s.GoTo != Point.Empty || bAIRunning) gbAttack.Deactivate();
          else gbAttack.Activate();
          if (s.Stamina < s.SearchCost || s.GoTo != Point.Empty || bAIRunning) gbSearch.Deactivate();
          else gbSearch.Activate();
          if (s.Stamina < s.UseItemCost || s.GoTo != Point.Empty || !s.HasUtilityItems() || bAIRunning) gbUseItem.Deactivate();
          else gbUseItem.Activate();
          if (s.Stamina < s.MovementCost || s.GoTo != Point.Empty || bAIRunning) {
            gbWest.Deactivate();
            gbEast.Deactivate();
            gbNorth.Deactivate();
            gbSouth.Deactivate();
          }
          else {
            gbWest.Activate();
            gbEast.Activate();
            gbNorth.Activate();
            gbSouth.Activate();
          }
        }

        GL.PushMatrix();
        GL.Translate(sx, sy, Const.GUILayer);
        s.DisplaySoldierDetails(SelectedEntity == s, hover == s);
        sy += PanelHeight + Const.GUIPanelGap;
        GL.PopMatrix();
      }
    }
    private void SetupGUITextures() {
      if (iMiscTexture == -1) iMiscTexture = Textures.GetMiscTexture();
      if (iItemTexture == -1) iItemTexture = Textures.GetItemTexture();
    }
    private void InitialiseGUIButtons() {
      // Initialise all on startup
      if (!bGUIButtonsInitialised) {
        lButtons.Clear();

        // ZoomTo buttons
        SetupZoomToButtons();

        // Direction Control buttons
        Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.Left);
        gbWest = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, (0.99f - Const.GUIPanelWidth) + FrameBorder, 0.0, ButtonSize, ButtonSize, SelectedSoldierMove, Utils.Direction.West);
        lButtons.Add(gbWest);
        tp = Textures.GetTexCoords(Textures.MiscTexture.Right);
        gbEast = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, (0.99f - Const.GUIPanelWidth) + (FrameBorder * 3) + (ButtonSize * 2), 0.0, ButtonSize, ButtonSize, SelectedSoldierMove, Utils.Direction.East);
        lButtons.Add(gbEast);
        tp = Textures.GetTexCoords(Textures.MiscTexture.Up);
        gbNorth = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, (0.99f - Const.GUIPanelWidth) + (FrameBorder * 2) + ButtonSize, 0.0, ButtonSize, ButtonSize, SelectedSoldierMove, Utils.Direction.North);
        lButtons.Add(gbNorth);
        tp = Textures.GetTexCoords(Textures.MiscTexture.Down);
        gbSouth = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, (0.99f - Const.GUIPanelWidth) + (FrameBorder * 2) + ButtonSize, 0.0, ButtonSize, ButtonSize, SelectedSoldierMove, Utils.Direction.South);
        lButtons.Add(gbSouth);

        // Misc controls
        tp = Textures.GetTexCoords(Textures.MiscTexture.Attack);
        gbAttack = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, (0.99f - Const.GUIPanelWidth) + (FrameBorder * 3) + (ButtonSize * 3) + (ButtonGap * 2), 0.0, ButtonSize * 1.5, ButtonSize * 1.5, SelectedSoldierAttack, null);
        lButtons.Add(gbAttack);
        tp = Textures.GetTexCoords(Textures.MiscTexture.Skills);
        gbUseItem = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, (0.99f - Const.GUIPanelWidth) + (FrameBorder * 3) + (ButtonSize * 4.5) + (ButtonGap * 4), 0.0, ButtonSize * 1.5, ButtonSize * 1.5, SelectedSoldierUseItems, null);
        lButtons.Add(gbUseItem);
        tp = Textures.GetTexCoords(Textures.MiscTexture.Inventory);
        gbInventory = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, (0.99f - Const.GUIPanelWidth) + (FrameBorder * 3) + (ButtonSize * 3) + (ButtonGap * 2), 0.0, ButtonSize * 1.5, ButtonSize * 1.5, SelectedSoldierInventory, null);
        lButtons.Add(gbInventory);
        tp = Textures.GetTexCoords(Textures.MiscTexture.Search);
        gbSearch = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, (0.99f - Const.GUIPanelWidth) + (FrameBorder * 3) + (ButtonSize * 4.5) + (ButtonGap * 4), 0.0, ButtonSize * 1.5, ButtonSize * 1.5, SelectedSoldierSearch, null);
        lButtons.Add(gbSearch);

        // Other buttons
        gbEndTurn = new GUIButton("End Turn", glMissionView, EndTurn);
        gbEndTurn.Activate();
        gbEndTurn.SetPosition(0.9, 0.93);
        gbEndTurn.SetSize(0.09, 0.05);
        gbEndTurn.SetBlend(true);

        gbTransition = new GUIButton("Transition", glMissionView, Transition);
        gbTransition.SetPosition(0.9, 0.85);
        gbTransition.SetSize(0.09, 0.05);
        gbTransition.SetBlend(true);

        gbEndMission = new GUIButton("End Mission", glMissionView, EndMission);
        gbEndMission.SetPosition(0.9, 0.77);
        gbEndMission.SetSize(0.09, 0.05);
        gbEndMission.SetBlend(true);

        // Done
        bGUIButtonsInitialised = true;

        // Set button state as required
        CheckForTransition();
      }

      // Switch control buttons on/off when required
      if (SelectedEntity == null || !(SelectedEntity is Soldier)) {
        gbWest.Deactivate();
        gbEast.Deactivate();
        gbNorth.Deactivate();
        gbSouth.Deactivate();
        gbAttack.Deactivate();
        gbSearch.Deactivate();
        gbInventory.Deactivate();
        gbUseItem.Deactivate();
      }
      else {
        gbWest.Activate();
        gbEast.Activate();
        gbNorth.Activate();
        gbSouth.Activate();
        gbAttack.Activate();
        gbSearch.Activate();
        gbInventory.Activate();
        gbUseItem.Activate();
      }
    }
    private void SetupZoomToButtons() {
      Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.Eye);
      if (miss.Soldiers.Count >= 1) { 
        if (gbZoomTo1 == null || gbZoomTo1.InternalData != miss.Soldiers[0]) {
          gbZoomTo1 = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, 0.99f - (ButtonSize + FrameBorder), 0.0, ButtonSize, ButtonSize, ZoomToSoldier, miss.Soldiers[0]);
          if (!lButtons.Contains(gbZoomTo1)) lButtons.Add(gbZoomTo1);
        }
        if (miss.Soldiers.Count >= 2) {
          if (gbZoomTo2 == null || gbZoomTo2.InternalData != miss.Soldiers[1]) {
            gbZoomTo2 = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, 0.99f - (ButtonSize + FrameBorder), 0.0, ButtonSize, ButtonSize, ZoomToSoldier, miss.Soldiers[1]);
            if (!lButtons.Contains(gbZoomTo2)) lButtons.Add(gbZoomTo2);
          }
          if (miss.Soldiers.Count >= 3) {
            if (gbZoomTo3 == null || gbZoomTo3.InternalData != miss.Soldiers[2]) {
              gbZoomTo3 = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, 0.99f - (ButtonSize + FrameBorder), 0.0, ButtonSize, ButtonSize, ZoomToSoldier, miss.Soldiers[2]);
              if (!lButtons.Contains(gbZoomTo3)) lButtons.Add(gbZoomTo3);
            }
            if (miss.Soldiers.Count >= 4) {
              if (gbZoomTo4 == null || gbZoomTo4.InternalData != miss.Soldiers[3]) {
                gbZoomTo4 = new GUIIconButton(glMissionView, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, 0.99f - (ButtonSize + FrameBorder), 0.0, ButtonSize, ButtonSize, ZoomToSoldier, miss.Soldiers[3]);
                if (!lButtons.Contains(gbZoomTo4)) lButtons.Add(gbZoomTo4);
              }
            }
          }
        }
      }
      if (miss.Soldiers.Count < 4) {
        if (lButtons.Contains(gbZoomTo4)) lButtons.Remove(gbZoomTo4);
        gbZoomTo4 = null;
      }
      if (miss.Soldiers.Count < 3) {
        if (lButtons.Contains(gbZoomTo3)) lButtons.Remove(gbZoomTo3);
        gbZoomTo3 = null;
      }
      if (miss.Soldiers.Count < 2) {
        if (lButtons.Contains(gbZoomTo2)) lButtons.Remove(gbZoomTo2);
        gbZoomTo2 = null;
      }
      if (miss.Soldiers.Count == 0) {
        if (lButtons.Contains(gbZoomTo1)) lButtons.Remove(gbZoomTo1);
        gbZoomTo1 = null;
      }
    }
    private void DrawTargetGrid() {
      GL.Color3(1.0, 0.0, 0.0);
      GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Line);
      GL.Begin(BeginMode.Quads);
      for (int y = 0; y < level.Height; y++) {
        for (int x = 0; x < level.Width; x++) {
          if (!TargetMap[x, y]) continue;
          GL.Vertex3(x, y, Const.DoodadLayer);
          GL.Vertex3(x + 1, y, Const.DoodadLayer);
          GL.Vertex3(x + 1, y + 1, Const.DoodadLayer);
          GL.Vertex3(x, y + 1, Const.DoodadLayer);
        }
      }
      GL.End();
      GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Fill);
    }

    private void DrawAoEGrid() {
      GL.Color4(1.0, 0.0, 0.0, 0.2);
      //GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Line);
      GL.Enable(EnableCap.Blend);
      GL.BlendFunc(BlendingFactorSrc.SrcAlpha, BlendingFactorDest.OneMinusSrcAlpha);
      GL.Begin(BeginMode.Quads);
      for (int y = (int)Math.Max(hovery - AoERadius, 0); y < (int)Math.Min(hovery + AoERadius + 1, level.Height); y++) {
        for (int x = (int)Math.Max(hoverx - AoERadius, 0); x < (int)Math.Min(hoverx + AoERadius + 1, level.Width); x++) {
          if (!AoEMap[x, y]) continue;
          GL.Vertex3(x, y, Const.DoodadLayer);
          GL.Vertex3(x + 1, y, Const.DoodadLayer);
          GL.Vertex3(x + 1, y + 1, Const.DoodadLayer);
          GL.Vertex3(x, y + 1, Const.DoodadLayer);
        }
      }
      GL.End();
      GL.Disable(EnableCap.Blend);
      //GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Fill);
    }
    private void DrawTravelGrid() {
      GL.Color3(0.0, 1.0, 0.0);
      GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Line);
      GL.Begin(BeginMode.Quads);
      for (int y = 0; y < level.Height; y++) {
        for (int x = 0; x < level.Width; x++) {
          if (DistMap[x, y] == -1) continue;
          GL.Vertex3(x, y, Const.DoodadLayer);
          GL.Vertex3(x + 1, y, Const.DoodadLayer);
          GL.Vertex3(x + 1, y + 1, Const.DoodadLayer);
          GL.Vertex3(x, y + 1, Const.DoodadLayer);
        }
      }
      GL.End();
      GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Fill);
    }
    private void DrawTravelPath() {
      if (lCurrentPath == null || lCurrentPath.Count == 0) return;
      if (SelectedEntity == null || !(SelectedEntity is Soldier)) return;
      GL.Color3(0.0, 1.0, 0.0);
      GL.Begin(BeginMode.LineStrip);
      GL.Vertex3(SelectedEntity.X + 0.5, SelectedEntity.Y + 0.5, Const.DoodadLayer);
      foreach (Point pt in lCurrentPath) {
        // TODO : This needs to start at the square that the entity has currently got to, 
        GL.Vertex3(pt.X + 0.5, pt.Y + 0.5, Const.DoodadLayer);
      }
      GL.Vertex3(hoverx + 0.5, hovery + 0.5, Const.DoodadLayer);
      GL.End();
      GL.Begin(BeginMode.Quads);
      GL.Vertex3(hoverx + 0.45, hovery + 0.45, Const.DoodadLayer);
      GL.Vertex3(hoverx + 0.55, hovery + 0.45, Const.DoodadLayer);
      GL.Vertex3(hoverx + 0.55, hovery + 0.55, Const.DoodadLayer);
      GL.Vertex3(hoverx + 0.45, hovery + 0.55, Const.DoodadLayer);
      GL.End();
    }
    private void DrawHoverFrame(int xpos, int ypos) {
      double px = xpos + 0.5, py = ypos + 0.5;
      double xSize = 1.0, ySize = 1.0;
      // Hovering over a large entity
      IEntity en = level.GetEntityAt(xpos, ypos);
      if (en != null && en.Size > 1) {
        px = en.X + (en.Size / 2.0);
        py = en.Y + (en.Size / 2.0);
        xSize = en.Size;
        ySize = en.Size;
      }
      // Hovering over a door
      else if (level.Map[xpos, ypos] == MissionLevel.TileType.DoorHorizontal || level.Map[xpos, ypos] == MissionLevel.TileType.OpenDoorHorizontal) {
        int endx = xpos, startx = xpos;
        while (startx - 1 > 0 && level.Map[startx - 1, ypos] == level.Map[xpos, ypos]) startx--;
        while (endx + 1 < level.Width - 1 && level.Map[endx + 1, ypos] == level.Map[xpos, ypos]) endx++;
        px = (startx + endx) / 2.0 + 0.5;
        xSize = Math.Abs(startx - endx) + 1.0;
      }
      else if (level.Map[xpos, ypos] == MissionLevel.TileType.DoorVertical || level.Map[xpos, ypos] == MissionLevel.TileType.OpenDoorVertical) {
        int endy = ypos, starty = ypos;
        while (starty - 1 > 0 && level.Map[xpos, starty - 1] == level.Map[xpos, ypos]) starty--;
        while (endy + 1 < level.Height - 1 && level.Map[xpos, endy + 1] == level.Map[xpos, ypos]) endy++;
        py = (starty + endy) / 2.0 + 0.5;
        ySize = Math.Abs(starty - endy) + 1.0;
      }
      const double dFrame = 0.1;
      if (CurrentAction == SoldierAction.Attack || CurrentAction == SoldierAction.Item) GL.Color3(1.0, 0.0, 0.0);
      else GL.Color3(0.0, 1.0, 0.0);
      double dx = -(xSize / 2.0);
      double dy = -(ySize / 2.0);
      GL.Begin(BeginMode.QuadStrip);
      GL.Vertex3(px + dx, py + dy, Const.GUILayer);
      GL.Vertex3(px + dx + dFrame, py + dy + dFrame, Const.GUILayer);
      GL.Vertex3(px + dx, py + dy + ySize, Const.GUILayer);
      GL.Vertex3(px + dx + dFrame, py + dy + (ySize - dFrame), Const.GUILayer);
      GL.Vertex3(px + dx + xSize, py + dy + ySize, Const.GUILayer);
      GL.Vertex3(px + dx + (xSize - dFrame), py + dy + (ySize - dFrame), Const.GUILayer);
      GL.Vertex3(px + dx + xSize, py + dy, Const.GUILayer);
      GL.Vertex3(px + dx + (xSize - dFrame), py + dy + dFrame, Const.GUILayer);
      GL.Vertex3(px + dx, py + dy, Const.GUILayer);
      GL.Vertex3(px + dx + dFrame, py + dy + dFrame, Const.GUILayer);
      GL.End();
    }
    private void DrawSelectionTile(double px, double py, double dSize) {
      double d = -(dSize / 2.0);
      GL.Color3(1.0, 1.0, 1.0);
      GL.Enable(EnableCap.Texture2D);
      if (iSelectionTexID == -1) iSelectionTexID = Textures.GenerateSelectionTexture(); //Textures.GenerateHighlightTexture();
      GL.Enable(EnableCap.Blend);
      GL.BindTexture(TextureTarget.Texture2D, iSelectionTexID);
      GL.Begin(BeginMode.Quads);
      GL.TexCoord2(0.0, 0.0); GL.Vertex3(px + d, py + d, Const.DoodadLayer);
      GL.TexCoord2(1.0, 0.0); GL.Vertex3(px + d, py + d + dSize, Const.DoodadLayer);
      GL.TexCoord2(1.0, 1.0); GL.Vertex3(px + d + dSize, py + d + dSize, Const.DoodadLayer);
      GL.TexCoord2(0.0, 1.0); GL.Vertex3(px + d + dSize, py + d, Const.DoodadLayer);
      GL.End();
      GL.Disable(EnableCap.Blend);
      GL.Disable(EnableCap.Texture2D);
    }
    
    // Setup mouse-hover context menu
    private void SetupContextMenu() {
      if (gpSelect == null) gpSelect = new GUIPanel(glMissionView);
      gpSelect.Reset();
      gpSelect.ClickX = hoverx;
      gpSelect.ClickY = hovery;
      gpSelect.SetIconScale(0.7);
      gpSelect.PanelX = (double)mx / (double)glMissionView.Width + 0.01;
      gpSelect.PanelY = (double)my / (double)glMissionView.Height + 0.01;
      CheckHover();

      if (SelectedEntity == null || !(SelectedEntity is Soldier)) {
        gpSelect.Deactivate();
        return;
      }
      Soldier s = (Soldier)SelectedEntity;
      if (s.GoTo != Point.Empty) return;
      if (hoverx < 0 || hoverx >= level.Width || hovery < 0 || hovery >= level.Height) {
        gpSelect.Deactivate();
        return;
      }
      // Open doors
      if (level.Map[hoverx, hovery] == MissionLevel.TileType.DoorHorizontal) {
        bool bEntityIsAdjacent = level.EntityIsAdjacentToDoor(SelectedEntity, hoverx, hovery);
        Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.OpenDoor);
        gpSelect.InsertIcon(I_OpenDoor, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, bEntityIsAdjacent, null);
      }
      if (level.Map[hoverx, hovery] == MissionLevel.TileType.DoorVertical) {
        bool bEntityIsAdjacent = level.EntityIsAdjacentToDoor(SelectedEntity, hoverx, hovery);
        Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.OpenDoor);
        gpSelect.InsertIcon(I_OpenDoor, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, bEntityIsAdjacent, null);
      }
      // Close doors
      if (level.Map[hoverx, hovery] == MissionLevel.TileType.OpenDoorHorizontal && level.GetEntityAt(hoverx, hovery) == null) {
        bool bEntityIsAdjacent = level.EntityIsAdjacentToDoor(SelectedEntity, hoverx, hovery);
        Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.CloseDoor);
        gpSelect.InsertIcon(I_CloseDoor, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, bEntityIsAdjacent, null);
      }
      if (level.Map[hoverx, hovery] == MissionLevel.TileType.OpenDoorVertical && level.GetEntityAt(hoverx, hovery) == null) {
        bool bEntityIsAdjacent = level.EntityIsAdjacentToDoor(SelectedEntity, hoverx, hovery);
        Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.CloseDoor);
        gpSelect.InsertIcon(I_CloseDoor, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, bEntityIsAdjacent, null);
      }
      // Passable square
      if (Utils.IsPassable(level.Map[hoverx, hovery])) {
        IEntity en = level.GetEntityAt(hoverx, hovery);
        // Walk to this point
        if (en == null) {
          Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.Walk);
          bool bIsInRange = DistMap[hoverx, hovery] != -1;
          gpSelect.InsertIcon(I_GoTo, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, bIsInRange, null);
        }
        // Attack a creature
        else if (en is Creature) {
          Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.Attack);
          bool bIsInRange = SelectedEntity.CanSee(en) && SelectedEntity.RangeTo(en) <= SelectedEntity.AttackRange;
          bool bEnabled = (bIsInRange && (s.Stamina >= s.AttackCost));
          if (s.EquippedWeapon != null && s.EquippedWeapon.Type.Area > 0) bEnabled = false;
          gpSelect.InsertIcon(I_Attack, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, bEnabled, null);
        }
      }
      // Click on self
      if (hoverx == s.X && hovery == s.Y) {
        bool bHasUtilityItems = s.HasUtilityItems();
        Tuple<double, double> tpReuse = Textures.GetTexCoords(Textures.MiscTexture.Reuse);
        GUIPanel gpItems = null;
        if (bHasUtilityItems) {
          bool bEnabled = s.Stamina >= s.UseItemCost;
          gpItems = new GUIPanel(glMissionView);
          // Set up list of items
          foreach (ItemType it in s.GetUtilityItems()) {
            Tuple<double, double> tp2 = Textures.GetTexCoords(it);
            IPanelItem ip = gpItems.InsertIcon(it.ItemID, iItemTexture, tp2.Item1, tp2.Item2, Textures.ItemTextureWidth, Textures.ItemTextureHeight, bEnabled, null);
            if (it.ItemEffect != null && !it.ItemEffect.SingleUse) {
              ip.SetOverlay(iMiscTexture, new Vector4d(tpReuse.Item1, tpReuse.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight), new Vector4d(0.7, 0.0, 0.3, 0.3));
            }
          }
        }
        Tuple<double, double> tpInv = Textures.GetTexCoords(Textures.MiscTexture.Inventory);
        gpSelect.InsertIcon(I_UseItem, iMiscTexture, tpInv.Item1, tpInv.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, bHasUtilityItems, gpItems);
      }
      if (gpSelect.Count == 0) {
        gpSelect.Deactivate();
        return;
      }
      gpSelect.Activate();
      glMissionView.Invalidate();
    }

    #region ButtonHandlers
    private void CentreView(IEntity ent) {
      fMissionViewX = ent.X;
      fMissionViewY = ent.Y;
      glMissionView.Invalidate();
    }
    private void CentreViewForceRedraw(IEntity ent) {
      fMissionViewX = ent.X;
      fMissionViewY = ent.Y;
      glMissionView.Invalidate();
      ThisDispatcher.Invoke(() => { glMissionView_Paint(null, null); });
      //glMissionView_Paint(null, null);  // This line causes fun when called from a thread. Could probably do this with a dispatcher & lock?
    }
    private void ZoomToSoldier(GUIIconButton sender) {
      if (bAIRunning) return;
      Soldier s = sender.InternalData as Soldier;
      if (s == null) throw new Exception("ZoomToSoldier: GUIIconButton did not have Soldier set as internal data");
      SetSelectedEntity(s);
      CentreView(s);
    }
    private void SelectedSoldierMove(GUIIconButton sender) {
      if (bAIRunning) return;
      Utils.Direction d = (Utils.Direction)sender.InternalData;
      //if (d == null) throw new Exception("MoveSelectedSoldier: GUIIconButton did not have Direction set as internal data");
      if (SelectedEntity == null || !(SelectedEntity is Soldier)) throw new Exception("SelectedSoldierMove: SelectedSoldier not set!");
      Soldier s = SelectedEntity as Soldier;
      MoveSoldier(s, d);
      CurrentAction = SoldierAction.None;
      ActionItem = null;
      if (s.PlayerTeam != null) { // Not dead
        GenerateDistMap(SelectedEntity as Soldier);
        GenerateDetectionMap();
        CheckForTraps(s);
      }
      glMissionView.Invalidate();
    }
    private void SelectedSoldierAttack(GUIIconButton sender) {
      if (bAIRunning) return;
      if (SelectedEntity == null || !(SelectedEntity is Soldier)) throw new Exception("SelectedSoldierAttack: SelectedSoldier not set!");
      Soldier s = (Soldier)SelectedEntity;
      GenerateTargetMap(s, s.AttackRange);
      CurrentAction = SoldierAction.Attack;
      if (s.EquippedWeapon != null && s.EquippedWeapon.Type.Area > 0) {
        GenerateAoEMap(s.X, s.Y, s.EquippedWeapon.Type.Area);
      }
      glMissionView.Invalidate();
    }
    private void SelectedSoldierUseItems(GUIIconButton sender) {
      if (bAIRunning) return;
      if (SelectedEntity == null || !(SelectedEntity is Soldier)) throw new Exception("SelectedSoldierUseItems: SelectedSoldier not set!");
      using (UseItem ui = new UseItem(SelectedEntity as Soldier)) {
        ui.ShowDialog(this);
        if (ui.ChosenItem != null) {
          ActionItem = ui.ChosenItem.BaseType;
          CurrentAction = SoldierAction.Item;
          Soldier s = (Soldier)SelectedEntity;
          GenerateTargetMap(s, ActionItem.ItemEffect.Range);
          int sy = SelectedEntity.Y;
          int sx = SelectedEntity.X;
          GenerateAoEMap(sx, sy, ActionItem.ItemEffect.Radius);
          glMissionView.Invalidate();
        }
      }
    }
    private void SelectedSoldierInventory(GUIIconButton sender) {
      if (bAIRunning) return;
      if (SelectedEntity == null || !(SelectedEntity is Soldier)) throw new Exception("SelectedSoldierInventory: SelectedSoldier not set!");
      int sy = SelectedEntity.Y;
      int sx = SelectedEntity.X;
      Stash st = level.GetStashAtPoint(sx, sy);
      if (st == null) st = new Stash(new Point(sx, sy));
      EquipmentView eqv = new EquipmentView(SelectedEntity as Soldier, st);
      eqv.ShowDialog(this);
      level.ReplaceStashAtPosition(sx, sy, st);
      glMissionView.Invalidate();
    }
    private void SelectedSoldierSearch(GUIIconButton sender) {
      if (bAIRunning) return;
      if (SelectedEntity == null || !(SelectedEntity is Soldier s)) return;
      if (s.Stamina < s.SearchCost) return;
      List<string> lFound = s.PerformSearch(level);
      if (lFound.Count == 0) MessageBox.Show(this, "Despite a thorough search, you found nothing");
      else MessageBox.Show(this, String.Join("\n", lFound));
      GenerateDistMap(SelectedEntity as Soldier);
      GenerateDetectionMap();
      level.CalculatePlayerVisibility();
      glMissionView.Invalidate();
    }
    private async void EndTurn() {
      if (bAIRunning) return;
      foreach (Soldier s in level.Soldiers) {
        if (s.GoTo != Point.Empty) return; // Can't end turn if soldiers are still moving
      }

      if (miss.Soldiers.Count == 0) {
        Result = MissionResult.Defeat;
        this.Close();
      }

      bAIRunning = true;
      saveGameToolStripMenuItem.Enabled = false;
      loadGameToolStripMenuItem.Enabled = false;
      exitGameToolStripMenuItem.Enabled = false;
      abandonMissionToolStripMenuItem.Enabled = false;

      // Handle periodic effects not aimed at an entity e.g. burning floor, delayed-timer explosives
      // TODO

      // Reset stamina, do periodic effects etc.
      List<Soldier> lSoldiers = new List<Soldier>(miss.Soldiers); // In case one dies
      foreach (Soldier s in lSoldiers) {
        await Task.Run(() => s.EndOfTurn(AddNewEffect, CentreViewForceRedraw, PlaySoundThreaded, AnnounceMessage));
        if (s.PlayerTeam == null && SelectedEntity == s) SelectedEntity = null;
      }

      // Creature AI
      await Task.Run(() => level.RunCreatureTurn(AddNewEffect, CentreViewForceRedraw, PostMoveCheck, glMissionView.Invalidate, PlaySoundThreaded, AnnounceMessage));

      // All done
      if (SelectedEntity != null && SelectedEntity is Soldier se && se.PlayerTeam == null) SelectedEntity = null;
      GenerateDistMap(SelectedEntity as Soldier);
      GenerateDetectionMap();
      if (SelectedEntity != null) SelectedEntity.UpdateVisibility(level);
      level.CalculatePlayerVisibility();
      glMissionView.Invalidate();
      bAIRunning = false;
      saveGameToolStripMenuItem.Enabled = true;
      loadGameToolStripMenuItem.Enabled = true;
      exitGameToolStripMenuItem.Enabled = true;
      abandonMissionToolStripMenuItem.Enabled = true;
      Const.dtTime.AddSeconds(10);
    }
    private void PlaySoundThreaded(string strSound) {
      ThisDispatcher.BeginInvoke((Action)(() => { SoundEffects.PlaySound(strSound); }));
      //ThisDispatcher.Invoke(() => { SoundEffects.PlaySound(strSound); });
    }
    private void AnnounceMessage(string strMsg) {
      ThisDispatcher.Invoke(() => { MessageBox.Show(this, strMsg); });
    }
    private void PostMoveCheck(IEntity en) {
      // Stuff we need to check after a creature moves
      GenerateDetectionMap();
      foreach (Soldier s in level.Soldiers) {
        if (UpdateDetectionForSoldier(s)) {
          AnnounceMessage(s.Name + " has been detected by the enemy!");
        }
      }
    }
    private void Transition() {
      if (bAIRunning) return;
      int oldlev = miss.CurrentLevel;
      int newlev = oldlev;
      // Check if we're going up or down, or exiting
      if (level.CheckAllSoldiersAtEntrance()) {
        newlev--;
      }
      else if (level.CheckAllSoldiersAtExit()) {
        newlev++;
      }
      else return;

      // Leave the dungeon?
      if (newlev == -1) {
        this.Close(); // Form  closing event handler will deal with it
        return;
      }
      if (newlev >= miss.LevelCount) throw new Exception("Attempting to transition to illegal level");
      level.RemoveAllSoldiers();
      miss.SetCurrentLevel(newlev);
      level = miss.GetOrCreateCurrentLevel();

      // Redim the various maps
      TargetMap = new bool[level.Width, level.Height];
      DistMap = new int[level.Width, level.Height];
      AoEMap = new bool[level.Width, level.Height];
      DetectionMap = new bool[level.Width, level.Height];

      // Update all soldiers
      foreach (Soldier s in miss.Soldiers) {
        if (newlev > oldlev) level.AddSoldier(s);
        else level.AddSoldierAtExit(s);
        UpdateLevelAfterSoldierMove(s);
      }
      CentreView(miss.Soldiers[0]);
      glMissionView.Invalidate();
    }
    private void EndMission() {
      if (bAIRunning) return;
      if (level.AlertedEnemies) {
        MessageBox.Show(this, "You cannot leave this mission while there are enemies alerted to your presence.");
        return;
      }
      if (miss.Type == Mission.MissionType.RepelBoarders) {
        if (MessageBox.Show(this, "Deactivate ship defence systems and return to your posts?", "Boarders Defeated", MessageBoxButtons.YesNo) == DialogResult.No) return;
      }
      else {
        if (MessageBox.Show(this, "Leave this mission and return to the ship?", "Victorious mission", MessageBoxButtons.YesNo) == DialogResult.No) return;
      }
      Result = MissionResult.Victory;
      this.Close();
    }
    #endregion //  ButtonHandlers

    // Generate maps for overlays
    private void SetSelectedEntity(IEntity en) {
      SelectedEntity = en;
      GenerateDetectionMap();
      if (en != null && en is Soldier s) {
        GenerateDistMap(s);
      }
    }
    private void GenerateTargetMap(Soldier s, double range) {
      // Check every square
      for (int y = 0; y < level.Height; y++) {
        for (int x = 0; x < level.Width; x++) {
          if (!Utils.IsPassable(level.Map[x, y])) {
            TargetMap[x, y] = false;
          }
          else {
            TargetMap[x, y] = s.CanSee(x, y);
            if (TargetMap[x, y]) {
              // Check range
              double r2 = (x - s.X) * (x - s.X) + (y - s.Y) * (y - s.Y);
              TargetMap[x, y] = (r2 <= (range * range));
            }
          }
        }
      }
    }
    private void GenerateAoEMap(int px, int py, double range, int ox = -1, int oy = -1) {
      int startx = 0, starty = 0, endx = level.Width - 1, endy = level.Height - 1;
      // Check every square
      if (ox >= 0 && oy >= 0) {
        startx = (int)Math.Max(Math.Min(ox, px) - range, 0);
        starty = (int)Math.Max(Math.Min(oy, py) - range, 0);
        endx = (int)Math.Min(Math.Max(ox, px) + range, level.Width - 1);
        endy = (int)Math.Min(Math.Max(oy, py) + range, level.Height - 1);
      }
      for (int y = starty; y <= endy; y++) {
        for (int x = startx; x <= endx; x++) {
          if (!Utils.IsPassable(level.Map[x, y])) {
            AoEMap[x, y] = false;
          }
          else {
            double r2 = (x - px) * (x - px) + (y - py) * (y - py);
            AoEMap[x, y] = (r2 <= (range * range));
          }
        }
      }
      AoERadius = (int)Math.Ceiling(range);
    }
    private void GenerateDistMap(Soldier s) {
      if (s == null) return;
      for (int y = 0; y < level.Height; y++) {
        for (int x = 0; x < level.Width; x++) {
          DistMap[x, y] = -1;
        }
      }
      int maxdist = s.TravelRange;
      DistMap[s.X, s.Y] = 0;
      if (s.X > 0) FloodFillDist(s.X - 1, s.Y, 1, maxdist);
      if (s.X < level.Width - 1) FloodFillDist(s.X + 1, s.Y, 1, maxdist);
      if (s.Y > 0) FloodFillDist(s.X, s.Y - 1, 1, maxdist);
      if (s.Y < level.Height - 1) FloodFillDist(s.X, s.Y + 1, 1, maxdist);
    }
    private void FloodFillDist(int x, int y, int dist, int maxdist) {
      if (!level.Explored[x, y]) return;
      if (!Utils.IsPassable(level.Map[x, y])) return;
      if (level.GetEntityAt(x, y) != null) return;
      Trap tr = level.GetTrapAtPoint(x, y);
      if (tr != null && !tr.Hidden) return;
      if (dist > maxdist) return;
      DistMap[x, y] = dist;
      if (dist == maxdist) return;
      if (x > 0 && (DistMap[x - 1, y] == -1 || DistMap[x - 1, y] > dist)) FloodFillDist(x - 1, y, dist + 1, maxdist);
      if (x < level.Width - 1 && (DistMap[x + 1, y] == -1 || DistMap[x + 1, y] > dist)) FloodFillDist(x + 1, y, dist + 1, maxdist);
      if (y > 0 && (DistMap[x, y - 1] == -1 || DistMap[x, y - 1] > dist)) FloodFillDist(x, y - 1, dist + 1, maxdist);
      if (y < level.Height - 1 && (DistMap[x, y + 1] == -1 || DistMap[x, y + 1] > dist)) FloodFillDist(x, y + 1, dist + 1, maxdist);
    }
    private void GenerateDetectionMap() {
      // Clear the grid
      for (int y = 0; y < level.Height; y++) {
        for (int x = 0; x < level.Width; x++) {
          DetectionMap[x, y] = false;
        }
      }
      Soldier s = SelectedEntity as Soldier;
      if (s == null) return;

      // Check every nearby entity
      foreach (Creature cr in level.Creatures) {
        if (!cr.IsAlert && (level.Visible[cr.X,cr.Y] || Const.DEBUG_VISIBLE_ALL)) {
          double range = cr.SoldierVisibilityRange(s);
          for (int y = Math.Max(0, (int)Math.Floor(cr.Y - range)); y <= Math.Min(level.Height - 1, (int)Math.Ceiling(cr.Y + range)); y++) {
            for (int x = Math.Max(0, (int)Math.Floor(cr.X - range)); x <= Math.Min(level.Width - 1, (int)Math.Ceiling(cr.X + range)); x++) {
              if (Utils.IsPassable(level.Map[x,y]) && !DetectionMap[x,y]) {
                // Check range
                double r2 = (x - cr.X) * (x - cr.X) + (y - cr.Y) * (y - cr.Y);
                if (r2 <= (range * range)) { // Check range properly
                  DetectionMap[x, y] |= cr.CanSee(x, y);
                }
              }
            }
          }
        }
      }
    }

    // External event handlers
    public void KillSoldierOnView(Soldier s) {
      SetupZoomToButtons();
      if (SelectedEntity == s) SelectedEntity = null;
    }
  }
}
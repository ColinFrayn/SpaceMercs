﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace SpaceMercs.Dialogs {
  internal partial class ScanPlanet : Form {
    private readonly HabitableAO _aoScan;
    private readonly Team _playerTeam;
    private readonly Timer clockTick;
    private int iProgress = 0;

    public ScanPlanet(HabitableAO aoScan, Team team) {
      _aoScan = aoScan;
      _playerTeam = team;
      InitializeComponent();
      clockTick = new Timer();
      clockTick.Tick += new EventHandler(UpdateScan);
      clockTick.Interval = 250;

      if (!_aoScan.Scanned) {
        lbNone.Visible = false;
        dgMissions.Visible = false;
        pbScan.Visible = false;
        btRunMission.Text = "Scan Planet";
      }
      else DisplayMissionList();
    }

    private void RunScan() {
      // Scan for new missions
      pbScan.Value = 0;
      pbScan.Visible = true;
      btRunMission.Text = "Scanning...";
      btRunMission.Enabled = false;
      clockTick.Start();
    }
    private void UpdateScan(Object myObject, EventArgs myEventArgs) {
      iProgress++;
      pbScan.Value = Math.Min(iProgress, 20);
      if (iProgress > 21) {
        clockTick.Stop();
        ScanComplete();
      }
    }
    private void ScanComplete() {
      Random rnd = new Random();
      int nm = rnd.Next(3) + 1;
      if (_aoScan is Planet) nm++;
      if (_aoScan.Type == Planet.PlanetType.Oceanic) nm += rnd.Next(2) + 1;
      if (_aoScan.Type == Planet.PlanetType.Gas) nm -= rnd.Next(2) + 1;
      while (rnd.NextDouble() < 0.5) nm++;
      if (nm < 1) nm = 1;
      for (int n=0; n<nm; n++) {
        Mission m = Mission.CreateRandomScannerMission(_aoScan, rnd);
        _aoScan.AddMission(m);
      }
      pbScan.Visible = false;
      DisplayMissionList();
    }
    private void DisplayMissionList() {
      pbScan.Visible = false;
      btRunMission.Text = "Run Mission";
      btRunMission.Enabled = false;
      if (!_aoScan.MissionList.Any()) {
        dgMissions.Visible = false;
        lbNone.Visible = true;
        return;
      }
      lbNone.Visible = false;
      dgMissions.Visible = true;
      dgMissions.Rows.Clear();
      string[] arrRowMiss = new string[5];
      foreach (Mission miss in _aoScan.MissionList) {
        arrRowMiss[0] = miss.Summary;
        arrRowMiss[1] = Utils.MissionGoalToString(miss.Goal);
        if (miss.RacialOpponent != null) arrRowMiss[2] = miss.RacialOpponent.Name + " " + miss.PrimaryEnemy.Name;
        else arrRowMiss[2] = miss.PrimaryEnemy.Name;
        arrRowMiss[3] = miss.Diff.ToString();
        arrRowMiss[4] = Utils.MapSizeToDescription(miss.Size) + (miss.LevelCount > 1 ? " * " + miss.LevelCount.ToString() : "");

        dgMissions.Rows.Add(arrRowMiss);
        dgMissions.Rows[dgMissions.Rows.Count - 1].Tag = miss;
      }
      dgMissions.ClearSelection();
    }

    // Run selected mission *or* run a scan if no scan has yet been done
    private void btRunMission_Click(object sender, EventArgs e) {
      if (_playerTeam.CurrentPosition != _aoScan) {
        MessageBox.Show("Your team is no longer located here!");
        return;
      }
      if (!_aoScan.Scanned) {
        RunScan();
        return;
      }
      if (dgMissions.SelectedRows.Count != 1) return;
      RunMission(dgMissions.SelectedRows[0].Tag as Mission);
    }
    public void RunMission(Mission miss) {
      MissionView mv = new MissionView(miss, _playerTeam);

      // Check if we quit out of the mission before deploying
      if (mv.Result == MissionView.MissionResult.Aborted) return;

      // Do the mission here 
      _aoScan.RemoveMission(miss);
      mv.ShowDialog(this.Owner);
      _playerTeam.CeaseMission();

      // We didn't complete the mission, so reset it and replace it
      if (mv.Result != MissionView.MissionResult.Victory) {
        miss.ResetMission();
        _aoScan.AddMission(miss);
      }

      // Resolve the mission (either victory or destruction)
      if (mv.Result == MissionView.MissionResult.Victory) {
        if (miss.Goal == Mission.MissionGoal.Gather) {
          MessageBox.Show(this, "You returned safely to your ship\nYou can sell any gathered " + miss.MItem + "s at the nearest Colony", "Mission Victory");
        }
        else {
          if (miss.Goal == Mission.MissionGoal.FindItem) {
            MessageBox.Show(this, "You return the " + miss.MItem + " to the mission agent\nCash Reward = " + miss.Reward + "cr\nBonus Experience = " + miss.Experience + "xp each", "Mission Victory");
            if (!_playerTeam.RemoveItemFromStoresOrSoldiers(miss.MItem)) throw new Exception("Could not find quest item on Team");
          }
          else MessageBox.Show(this, "You were victorious\nBonus Experience = " + miss.Experience + "xp each", "Mission Victory");
          foreach (Soldier s in miss.Soldiers) {
            s.AddExperience(miss.Experience);
            s.CheckForLevelUp(AnnounceMessage);
          }
        }
      }
      else if (mv.Result == MissionView.MissionResult.Defeat) {
        MessageBox.Show(this, "You were defeated", "Mission Defeat");
        if (_playerTeam.SoldierCount == 0) {
          // Still alive?
          // TODO
        }
        // TODO: Handle mission defeat
        throw new NotImplementedException();
      }
      else if (mv.Result == MissionView.MissionResult.Evacuated) {
        // Remove any mission items so they can't be sold and the mission repeated ad infinitum
        if (miss.MItem != null) _playerTeam.RemoveItemFromStoresOrSoldiers(miss.MItem, 10000);
      }
      else if (mv.Result == MissionView.MissionResult.ExitGame) {
        Application.Exit();
      }
      else if (mv.Result == MissionView.MissionResult.Running) {
        return; // MissionView was closed forcefully
      }

      DisplayMissionList();
    }

    private void dgMissions_SelectionChanged(object sender, EventArgs e) {
      if (dgMissions.SelectedRows.Count == 1) btRunMission.Enabled = true;
      else btRunMission.Enabled = false;
    }
    private void AnnounceMessage(string strMsg) {
      MessageBox.Show(this, strMsg);
    }

    private void dgMissions_DoubleClick(object sender, EventArgs e) {
      if (dgMissions.SelectedRows.Count != 1) return;
      Mission miss = dgMissions.SelectedRows[0].Tag as Mission;
      MessageBox.Show(this, miss.GetDescription(), "Mission Details");
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace SpaceMercs.Dialogs {
  // Partial class including core functions and definitions
  partial class MapView : Form {
    public enum ViewMode { ViewMap, ViewSystem };
    private bool bLoaded = false;
    private int mx, my;
    private readonly LinkedList<Star> RecentlyVisited = null;
    public double Aspect { get { if (!bLoaded) return 1.0;  return (double)glMapView.Width / (double)glMapView.Height; } }
    private Matrix4 perspective;
    private ViewMode view = ViewMode.ViewMap;
    private AstronomicalObject aoSelected = null, aoHover = null;
    private Map GalaxyMap;
    private bool bShowLabels = true;
    private Team PlayerTeam = null;
    private int MinSectorX, MaxSectorX, MinSectorY, MaxSectorY;
    private readonly Timer clockTick;
    private DateTime lastLoad = DateTime.MinValue;

    // Macros
    private Star CurrentSystem { get { return PlayerTeam.CurrentPosition.GetSystem(); } }

    // Initialise the game
    public MapView() {
      InitializeComponent();
      DisableMenus();
      GalaxyMap = new Map();
      // Load static data
      if (!StaticData.LoadAll()) this.Close();
      RecentlyVisited = new LinkedList<Star>();
      perspective = new Matrix4();
      saveToolStripMenuItem.Enabled = false;
      SetDoubleClickTime(250);
      clockTick = new Timer();
      clockTick.Tick += new EventHandler(ClockTickProcessor);
      clockTick.Interval = 1000;
      clockTick.Start();
    }

    // This is the method to run when the timer is raised.
    private void ClockTickProcessor(Object myObject, EventArgs myEventArgs) {
      if (clockTick.Interval == 1) {  // resuming a mission after a load
        clockTick.Interval = 1000;
        if (TravelDetails != null) TravelDetails.ResumeMissionAfterReload();
        else if (PlayerTeam.CurrentMission != null) {
          if (PlayerTeam.CurrentPosition.Colony != null) {
            ColonyView cv = new ColonyView(PlayerTeam);
            cv.Show(this);
            cv.RunMission(PlayerTeam.CurrentMission);
          }
          else {
            ScanPlanet sp = new ScanPlanet(PlayerTeam.CurrentPosition, PlayerTeam);
            sp.Show(this);
            sp.RunMission(PlayerTeam.CurrentMission);
          }
        }
        return;
      }
      if (bLoaded && GalaxyMap.bMapSetup) {
        Const.dtTime = Const.dtTime.AddSeconds(1.0);
        if (PlayerTeam.PlayerShip.Hull <= 0.0) GameOver();
        glMapView.Invalidate();
      }
    }

    // Allow setting of the double-click time
    [DllImport("user32")]
    public static extern int SetDoubleClickTime(int wCount);

    // When the main dialog is loaded, set up some defaults
    private void glMapView_Load(object sender, EventArgs e) {
      fMapViewZ = Const.InitialMapViewZ;
      fMapViewX = fMapViewY = 0;
      bShowGridlines = true;
      bFadeUnvisited = true;
      bShowRangeCircles = true;
      bShowTradeRoutes = true;
      glMapView.MakeCurrent();
      SetupMapTextures();
      Planet.BuildPlanetHalo();
      GraphicsFunctions.Initialise(glMapView);
      Terrain.GenerateSeedMap();
      SetupGUIElements();
      bLoaded = true;
      SetupViewport();
      glMapView.Invalidate();
      SetupOptionsMenu();
    }

    // Main window is resized so setup viewport again
    private void glMapView_Resize(object sender, EventArgs e) {
      if (!bLoaded) return;
      SetupViewport();
      glMapView.Invalidate();
    }

    // Draw the planet view
    private void glMapView_Paint(object sender, PaintEventArgs e) {
      if (!bLoaded) return;

      // Set up default OpenGL rendering parameters
      PrepareScene();

      if (view == ViewMode.ViewMap) {
        DrawMap();
      }
      if (view == ViewMode.ViewSystem) {
        DrawSystem();
      }

      // Swap rendered surface to front
      glMapView.SwapBuffers();
    }

    // Set up the scene ready for rendering
    private void PrepareScene() {
      glMapView.MakeCurrent();
      GL.ClearColor(Color.Black);
      GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
      GL.CullFace(CullFaceMode.Back);
      GL.ShadeModel(ShadingModel.Smooth);
      GL.Enable(EnableCap.DepthTest);
      GL.Disable(EnableCap.Blend);
      GL.DepthFunc(DepthFunction.Lequal);
      GL.Hint(HintTarget.PerspectiveCorrectionHint, HintMode.Nicest);
      GL.DepthMask(true);
      GL.Disable(EnableCap.Texture2D);
    }

    // Setup the OpenGL viewport
    private void SetupViewport() {
      int w = glMapView.Width;
      int h = glMapView.Height;
      glMapView.MakeCurrent();
      // Set near/far clipping based on distance
      perspective = Matrix4.CreatePerspectiveFieldOfView(Const.MapViewportAngle, (float)Aspect, 0.05f, 5000.0f);
      GL.MatrixMode(MatrixMode.Projection);
      GL.LoadMatrix(ref perspective);
      GL.Viewport(0, 0, w, h); // Use all of the glMapView painting area
    }

    // Setup the details for a new game
    private void SetupNewGame(NewGame ng) {
      fMapViewZ = Const.InitialMapViewZ;
      aoSelected = null;
      aoHover = null;
      RecentlyVisited.Clear();
      bLoaded = true;
      CloseAllDialogs();
      PlayerTeam = new Team(ng, StaticData.Races[0]);
      if (PlayerTeam.CurrentPosition == null || PlayerTeam.CurrentPosition.Colony == null) throw new Exception("Did not set up PlayerTeam correctly - not at home planet!");
      PlayerTeam.CurrentPosition.Colony.UpdateStock(PlayerTeam);
      SetupOptionsMenu();
      glMapView.Invalidate();
      saveToolStripMenuItem.Enabled = true;
    }

    // Close down all dialogs
    private void CloseAllDialogs() {
      List<Form> FormsToClose = new List<Form>();
      foreach (Form f in Application.OpenForms) {
        if (f.GetType() != typeof(MapView)) FormsToClose.Add(f);
      }
      foreach (Form f in FormsToClose) {
        if (f.GetType() == typeof(MissionView)) ((MissionView)f).ForceClose = true;
        f.Close();
      }
    }

    // Key handlers
    private void glMapView_KeyUp(object sender, KeyEventArgs e) {
      // -- Applies to all views
      {
        if (e.KeyCode == Keys.C) { // Centre on selected AO
          if (aoSelected == null) {
            fMapViewX = CurrentSystem.MapPos.X;
            fMapViewY = CurrentSystem.MapPos.Y;
            glMapView.Invalidate();
          }
          else {
            fMapViewX = aoSelected.GetSystem().MapPos.X;
            fMapViewY = aoSelected.GetSystem().MapPos.Y;
            glMapView.Invalidate();
          }
        }
        if (e.KeyCode == Keys.L) { // Toggle on/off showing labels for stars, planets & moons
          if (bShowLabels) { bShowLabels = false; tlL.SetTextColor(Color.DimGray); }
          else { bShowLabels = true; tlL.SetTextColor(Color.White); }
        }
        if (e.KeyCode == Keys.Escape) { // Deselect
          if (aoSelected != null) aoSelected = null;
          else {
            if (view == ViewMode.ViewSystem) view = ViewMode.ViewMap;
          }
          glMapView.Invalidate();
        }
      }

      // -- Map view only
      if (view == ViewMode.ViewMap) {
        if (e.KeyCode == Keys.G) {  // Toggle on/off gridlines
          if (bShowGridlines) { bShowGridlines = false; tlG.SetTextColor(Color.DimGray); }
          else { bShowGridlines = true; tlG.SetTextColor(Color.White); }
        }
        if (e.KeyCode == Keys.V) {  // Toggle on/off fading of unvisited stars
          if (bFadeUnvisited) { bFadeUnvisited = false; tlV.SetTextColor(Color.DimGray); }
          else { bFadeUnvisited = true; tlV.SetTextColor(Color.White); }
        }
        if (e.KeyCode == Keys.R) {  // Toggle on/off range circles
          if (bShowRangeCircles) { bShowRangeCircles = false; tlR.SetTextColor(Color.DimGray); }
          else { bShowRangeCircles = true; tlR.SetTextColor(Color.White); }
        }
        if (e.KeyCode == Keys.A) {  // Toggle on/off trade routes
          if (bShowTradeRoutes) { bShowTradeRoutes = false; tlA.SetTextColor(Color.DimGray); }
          else { bShowTradeRoutes = true; tlA.SetTextColor(Color.White); }
        }
        if (e.KeyCode == Keys.F) {  // Toggle on/off ownership flags
          if (bShowFlags) { bShowFlags = false; tlF.SetTextColor(Color.DimGray); }
          else { bShowFlags = true; tlF.SetTextColor(Color.White); }
        }
        MapHover();
      }

      // -- System view only
      if (view == ViewMode.ViewSystem) {
        if (e.KeyCode == Keys.C) {  // Toggle on/off colony icons
          if (bShowColonies) { bShowColonies = false; tlC.SetTextColor(Color.DimGray); }
          else { bShowColonies = true; tlC.SetTextColor(Color.White); }
        }
        SystemHover();
      }

      glMapView.Invalidate();
    }
    private void MapView_KeyDown(object sender, KeyEventArgs e) {
      glMapView.Invalidate();
    }

    // Need to trap keypresses of e.g. Alt, Ctrl key alone, not as modifiers
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData) {
      glMapView.Invalidate();
      return base.ProcessCmdKey(ref msg, keyData);
    }

    // Keep track of recently visited systems
    private void UpdateMRUList(Star st) {
      LinkedListNode<Star> node = RecentlyVisited.First;
      while (node != null) {
        var next = node.Next;
        if (node.Value == st) {
          RecentlyVisited.Remove(node);
        }
        node = next;
      }
      RecentlyVisited.AddFirst(st);
      // Delete texmaps for systems not recently visited
      int len = RecentlyVisited.Count;
      if (len > Const.MRUSize) {
        for (int n = 0; n < (len - Const.MRUSize); n++) {
          RecentlyVisited.Last.Value.ClearData();
          RecentlyVisited.RemoveLast();
        }
      }
    }

    // Closing the window - shut down stuff
    private void glMapView_Close(object sender, FormClosingEventArgs e) {
      bLoaded = false;
    }

    // Mouse handling
    private void glMapView_MouseMove(object sender, MouseEventArgs e) {
      if (PlayerTeam == null) return;
      if ((DateTime.Now - lastLoad).TotalMilliseconds < 1000.0) return; // Just loaded. Don't process extra clicks and shift the view.
      if (e.Button == MouseButtons.Left) {
        float fScale = Const.MouseMoveScale * (float)fMapViewZ / 27.0f; // To make sure that the scrolling is a sensible speed regardless of zoom level
        if (Control.ModifierKeys == Keys.Control) fScale *= 2.5f;
        else if (Control.ModifierKeys == Keys.Shift) fScale /= 2.5f;
        fMapViewX -= (float)(e.X - mx) * fScale;
        fMapViewY += (float)(e.Y - my) * fScale;
        if (fMapViewX < (CurrentSystem.MapPos.X - Const.MaximumScrollRange)) fMapViewX = (CurrentSystem.MapPos.X - Const.MaximumScrollRange);
        if (fMapViewX > (CurrentSystem.MapPos.X + Const.MaximumScrollRange)) fMapViewX = (CurrentSystem.MapPos.X + Const.MaximumScrollRange);
        if (fMapViewY < (CurrentSystem.MapPos.Y - Const.MaximumScrollRange)) fMapViewY = (CurrentSystem.MapPos.Y - Const.MaximumScrollRange);
        if (fMapViewY > (CurrentSystem.MapPos.Y + Const.MaximumScrollRange)) fMapViewY = (CurrentSystem.MapPos.Y + Const.MaximumScrollRange);
        glMapView.Invalidate();
      }
      if (Const.DEBUG_MOUSE_POS) this.helpToolStripMenuItem.Text = "(" + mx + ", " + my + ") -> [" + mx + "," + my + "]";

      // Hover over GUI objects
      bool b1 = gbRenameObject.IsHover(mx, my);
      bool b2 = gbFlyTo.IsHover(mx, my);
      bool b3 = gbViewColony.IsHover(mx, my);
      bool b4 = gbScan.IsHover(mx, my);
      mx = e.X;
      my = e.Y;
      bool bUpdate = false;
      if (gbRenameObject.IsHover(mx, my) != b1) bUpdate = true;
      if (gbFlyTo.IsHover(mx, my) != b2) bUpdate = true;
      if (gbViewColony.IsHover(mx, my) != b3) bUpdate = true;
      if (gbScan.IsHover(mx, my) != b4) bUpdate = true;
      if (bUpdate) glMapView.Invalidate();
      if (view == ViewMode.ViewMap) MapHover();
      if (view == ViewMode.ViewSystem) SystemHover();
    }
    private void glMapView_MouseDown(object sender, MouseEventArgs e) {
      if (PlayerTeam == null) return;
      mx = e.X;
      my = e.Y;
    }
    private void glMapView_MouseWheel(object sender, MouseEventArgs e) {
      if (PlayerTeam == null) return;
      float delta = 0.0f;
      if (Control.ModifierKeys == Keys.Control) delta -= e.Delta / 50.0f;
      else if (Control.ModifierKeys == Keys.Shift) delta -= e.Delta / 500.0f;
      else delta -= e.Delta / 150.0f;
      fMapViewZ += delta;
      if (fMapViewZ < Const.MinimumMapViewZ) fMapViewZ = Const.MinimumMapViewZ;
      if (fMapViewZ > Const.MaximumMapViewZ) fMapViewZ = Const.MaximumMapViewZ;
      glMapView.Invalidate();
    }
    private void glMapView_MouseUp(object sender, MouseEventArgs e) {
      if (PlayerTeam == null) return;
      if (e.Button == MouseButtons.Right) {
        // Add right click stuff here, if needed
      }
      if (e.Button == MouseButtons.Left) {
        if (gbRenameObject.CaptureClick(mx, my)) return;
        if (gbFlyTo.CaptureClick(mx, my)) return;
        if (gbViewColony.CaptureClick(mx, my)) return;
        if (gbScan.CaptureClick(mx, my)) return;
        if (aoHover != null) aoSelected = aoHover;
        SetSelection();
        glMapView.Invalidate();
      }
    }
    private void glMapView_DoubleClick(object sender, MouseEventArgs e) {
      if (PlayerTeam == null) return;
      if (e.Button == MouseButtons.Left) {
        if (aoHover != null) aoSelected = aoHover;
        // Zoom in to system
        if (view == ViewMode.ViewMap && aoSelected != null && aoSelected.AOType == AstronomicalObject.AstronomicalObjectType.Star) {
          Star st = (Star)aoSelected;
          if (st.Visited) {
            SystemStar = st;
            st.GeneratePlanets(GalaxyMap.PlanetDensity);
            view = ViewMode.ViewSystem;
            aoSelected = null;
            gbRenameObject.Deactivate();
            gbFlyTo.Deactivate();
            gbViewColony.Deactivate();
            gbScan.Deactivate();
          }
          else {
            MessageBox.Show(this, "You have not yet visited that system");
          }
        }
        glMapView.Invalidate();
      }
    }

    // Setup the current selection as the true selection. Set up text, textures etc.
    private void SetSelection() {
      if (aoSelected != null) {
        if (aoSelected.AOType == AstronomicalObject.AstronomicalObjectType.Star) {
          Star st = (Star)aoSelected;
          if (!String.IsNullOrEmpty(st.Name)) tlSel1.UpdateText(st.Name);
          else tlSel1.UpdateText("Unnamed Star");
          tlSel2.UpdateText("M = " + Math.Round(st.Mass, 2).ToString() + " Sol");
          tlSel3.UpdateText("R = " + Math.Round(st.radius / Const.Million, 0).ToString() + " Mm");
          tlSel4.UpdateText("Type " + st.StarType);
          tlSel5.UpdateText("(" + Math.Round(st.MapPos.X, 1) + "," + Math.Round(st.MapPos.Y, 1) + ")");
        }
        if (aoSelected.AOType == AstronomicalObject.AstronomicalObjectType.Planet) {
          Planet pl = (Planet)aoSelected;
          if (!String.IsNullOrEmpty(pl.Name)) tlSel1.UpdateText(pl.Name);
          else tlSel1.UpdateText("Unnamed Planet");
          tlSel2.UpdateText(pl.Type.ToString());
          tlSel3.UpdateText("R = " + Math.Round(pl.radius / 1000.0, 0).ToString() + "km");
          string strTemp = "Temp = " + pl.Temperature + "K";
          //strTemp += "  <" + pl.GetTempRange(Const.races[0]).ToString() + ">";
          tlSel4.UpdateText(strTemp);
          tlSel5.UpdateText("Orbit = " + Math.Round(pl.orbit / Const.AU, 2).ToString() + " AU");
          //tw.Update(iTextSelected4, "Dist = " + Math.Round(GraphicsFunctions.ViewDistance(pl), 3).ToString() + "Gm");
        }
        if (aoSelected.AOType == AstronomicalObject.AstronomicalObjectType.Moon) {
          Moon mn = (Moon)aoSelected;
          tlSel1.UpdateText("Moon " + (mn.ID + 1).ToString());
          tlSel2.UpdateText(mn.Type.ToString());
          tlSel3.UpdateText("R = " + Math.Round(mn.radius /1000.0, 0).ToString() + "km");
          tlSel4.UpdateText("Temp = " + mn.Temperature + "K");
          tlSel5.UpdateText("Orbit = " + Math.Round(mn.orbit / Const.Million, 0).ToString() + " Mm");
        }
      }
      SetAOButtonsOnGUI(aoSelected);
    }

    // External triggers
    public void RefreshView() {
      glMapView.Invalidate();
    }
    public void SaveGame() {
      saveToolStripMenuItem.PerformClick();
    }
    public void LoadGame() {
      loadToolStripMenuItem.PerformClick();
    }

    // Finish travelling
    public void ArriveAt(AstronomicalObject aoTo) {
      // Close colonyview if open
      foreach (Form f in Application.OpenForms) {
        if (f.GetType() == typeof(ColonyView)) { f.Close(); break; }
      }
      aoTo.GetSystem().SetVisited(true);
      aoTo.GetSystem().UpdateColonies();
      MessageBox.Show(this, "You have arrived at your destination");
      PlayerTeam.CurrentPosition = TravelDetails.Destination;
      if (PlayerTeam.CurrentPosition.Colony != null) PlayerTeam.CurrentPosition.Colony.UpdateStock(PlayerTeam); // Make sure we get up to date with what this colony has in store
      TravelDetails = null;
      SetAOButtonsOnGUI(aoSelected);
    }

    // Player has been destroyed
    private void GameOver() {
      clockTick.Stop();
      MessageBox.Show(this, "Game Over! Please start a new game or load a saved game to continue playing");
    }

    #region Menu Code
    // Disable/enable the game menus
    private void DisableMenus() {
      saveToolStripMenuItem.Enabled = false;
      shipToolStripMenuItem.Enabled = false;
      teamToolStripMenuItem.Enabled = false;
      colonyToolStripMenuItem.Enabled = false;
      racesToolStripMenuItem.Enabled = false;
    }
    private void EnableMenus() {
      saveToolStripMenuItem.Enabled = true;
      shipToolStripMenuItem.Enabled = true;
      teamToolStripMenuItem.Enabled = true;
      colonyToolStripMenuItem.Enabled = true;
      racesToolStripMenuItem.Enabled = true;
    }

    // Display the "About" box
    private void aboutToolStripMenuItem_Click(object sender, EventArgs e) {
      MessageBox.Show(this, "SpaceMercs v" + Const.strVersion + "\n(c) 2016 Colin Frayn\nwww.frayn.net", "About SpaceMercs", MessageBoxButtons.OK);
    }

    #region File Menu
    private void newToolStripMenuItem_Click(object sender, EventArgs e) {
      // Need to check to see if we already have a map set up
      if (GalaxyMap.bMapSetup) {
        if (MessageBox.Show(this, "You are in the middle of a game.\nGenerating a new game will lose all unsaved progress.\nAre you sure you want to continue?",
                            "Are you sure?", MessageBoxButtons.OKCancel) == DialogResult.Cancel) {
          return;
        }
      }

      // Set up the new game dialog box
      NewGame ng = new NewGame();
      DialogResult foo = ng.ShowDialog(this);
      if (foo == DialogResult.OK) {
        try {
          glMapView.MakeCurrent();
          GalaxyMap.Generate(ng);
          SetupNewGame(ng);
          EnableMenus();
          SetAOButtonsOnGUI(aoSelected);
          glMapView.Invalidate();
        }
        catch (Exception ex) {
          MessageBox.Show(this, ex.ToString());
        }
      }
    }
    private void loadToolStripMenuItem_Click(object sender, EventArgs e) {
      bool bTick = false;
      // Need to check to see if we already have a map set up
      if (TravelDetails != null) bTick = TravelDetails.StopTimer();
      if (GalaxyMap.bMapSetup == true) {
        if (MessageBox.Show(this, "You are in the middle of a game.\nLoading a game will lose all unsaved progress.\nAre you sure you want to continue?",
                            "Are you sure?", MessageBoxButtons.OKCancel) == DialogResult.Cancel) {
          if (TravelDetails != null && bTick) TravelDetails.StartTimer();
          return;
        }
      }

      // Get the filename
      OpenFileDialog ofd = new OpenFileDialog();
      ofd.Filter = "SpaceMercs Savegame Files (*.sve)|*.sve|All files (*.*)|*.*";
      ofd.FilterIndex = 1;
      DialogResult result = ofd.ShowDialog(this);
      if (result == DialogResult.OK) {
        try {
          Tuple<Map,Team,Travel> tp = LoadGame(ofd.FileName);
          // If we get here then it loaded OK, so overwrite everything
          GalaxyMap = tp.Item1;
          PlayerTeam = tp.Item2;
          TravelDetails = tp.Item3;

          // Setup GUI
          aoSelected = null;
          aoHover = null;
          fMapViewZ = Const.InitialMapViewZ;
          EnableMenus();
          bLoaded = true;
          RecentlyVisited.Clear();

          // Close down any windows
          CloseAllDialogs();
          SetupOptionsMenu();

          // Zoom to current location
          SystemStar = PlayerTeam.CurrentPosition.GetSystem();
          fMapViewX = PlayerTeam.CurrentPosition.GetMapLocation().X;
          fMapViewY = PlayerTeam.CurrentPosition.GetMapLocation().Y;
          lastLoad = DateTime.Now;
          SetAOButtonsOnGUI(aoSelected);
          glMapView.Invalidate();

          // If we're on a mission then set it up
          clockTick.Interval = 1; // Make sure we resume missions, but first let's quit out of this process so other windows can close
          return;
        }
        catch (Exception ex) {
          MessageBox.Show(this, ex.ToString(), "Load Game Failed", MessageBoxButtons.OK);
          if (TravelDetails != null && bTick) TravelDetails.StartTimer();
          return;
        }
      }
      else if (TravelDetails != null && bTick) TravelDetails.StartTimer();
    }
    private void saveToolStripMenuItem_Click(object sender, EventArgs e) {
      if (GalaxyMap.bMapSetup == false) return;
      bool bTick = false;
      if (TravelDetails != null) bTick = TravelDetails.StopTimer();

      // Get the filename
      SaveFileDialog sfd = new SaveFileDialog();
      sfd.Filter = "SpaceMercs Savegame Files (*.sve)|*.sve|All files (*.*)|*.*";
      sfd.FilterIndex = 1;
      DialogResult result = sfd.ShowDialog(this);
      if (result == DialogResult.OK) {
        try {
          SaveGame(sfd.FileName);
        }
        catch (Exception ex) {
          MessageBox.Show(this, ex.ToString(), "Save Game Failed", MessageBoxButtons.OK);
          return;
        }
        finally {
          if (TravelDetails != null && bTick) TravelDetails.StartTimer();
        }
      }
    }
    private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
      // Need to check to see if we already have a map set up
      if (GalaxyMap.bMapSetup == true) {
        if (MessageBox.Show(this, "You are in the middle of a game.\nExiting will lose all unsaved progress.\nAre you sure you want to continue?",
                            "Are you sure?", MessageBoxButtons.OKCancel) == DialogResult.Cancel) {
          return;
        }
      }
      this.Close();
    }
    #endregion

    #region Options Menu
    private void SetupOptionsMenu() {
      if (bShowLabels) showLabelsToolStripMenuItem.Checked = true;
      else showLabelsToolStripMenuItem.Checked = false;
      if (bShowGridlines) showMapGridToolStripMenuItem.Checked = true;
      else showMapGridToolStripMenuItem.Checked = false;
      if (bFadeUnvisited) fadeUnvisitedStarsToolStripMenuItem.Checked = true;
      else fadeUnvisitedStarsToolStripMenuItem.Checked = false;
      if (bShowRangeCircles) showRangeCirclesToolStripMenuItem.Checked = true;
      else showRangeCirclesToolStripMenuItem.Checked = false;
      if (bShowTradeRoutes) showTradeRoutesToolStripMenuItem.Checked = true;
      else showTradeRoutesToolStripMenuItem.Checked = false;
      if (bShowFlags) showFlagsToolStripMenuItem.Checked = true;
      else showFlagsToolStripMenuItem.Checked = false;
      if (bShowColonies) showColoniesToolStripMenuItem.Checked = true;
      else showColoniesToolStripMenuItem.Checked = false;
    }
    private void showLabelsToolStripMenuItem_Click(object sender, EventArgs e) {
      if (bShowLabels) {
        bShowLabels = false;
        showLabelsToolStripMenuItem.Checked = false;
      }
      else {
        bShowLabels = true;
        showLabelsToolStripMenuItem.Checked = true;
      }
      glMapView.Invalidate();
    }
    private void showMapGridToolStripMenuItem_Click(object sender, EventArgs e) {
      if (bShowGridlines) {
        bShowGridlines = false;
        showMapGridToolStripMenuItem.Checked = false;
      }
      else {
        bShowGridlines = true;
        showMapGridToolStripMenuItem.Checked = true;
      }
      glMapView.Invalidate();
    }
    private void fadeUnvisitedStarsToolStripMenuItem_Click(object sender, EventArgs e) {
      if (bFadeUnvisited) {
        bFadeUnvisited = false;
        fadeUnvisitedStarsToolStripMenuItem.Checked = false;
      }
      else {
        bFadeUnvisited = true;
        fadeUnvisitedStarsToolStripMenuItem.Checked = true;
      }
    }
    private void showRangeCirclesToolStripMenuItem_Click(object sender, EventArgs e) {
      if (bShowRangeCircles) {
        bShowRangeCircles = false;
        showRangeCirclesToolStripMenuItem.Checked = false;
      }
      else {
        bShowRangeCircles = true;
        showRangeCirclesToolStripMenuItem.Checked = true;
      }
    }
    private void showTradeRoutesToolStripMenuItem_Click(object sender, EventArgs e) {
      if (bShowTradeRoutes) {
        bShowTradeRoutes = false;
        showTradeRoutesToolStripMenuItem.Checked = false;
      }
      else {
        bShowTradeRoutes = true;
        showTradeRoutesToolStripMenuItem.Checked = true;
      }
    }
    private void showFlagsToolStripMenuItem_Click(object sender, EventArgs e) {
      if (bShowFlags) {
        bShowFlags = false;
        showFlagsToolStripMenuItem.Checked = false;
      }
      else {
        bShowFlags = true;
        showFlagsToolStripMenuItem.Checked = true;
      }
    }
    private void showColoniesToolStripMenuItem_Click(object sender, EventArgs e) {
      if (bShowColonies) {
        bShowColonies = false;
        showColoniesToolStripMenuItem.Checked = false;
      }
      else {
        bShowColonies = true;
        showColoniesToolStripMenuItem.Checked = true;
      }
    }
    
    #endregion

    #region View Menu
    private void shipToolStripMenuItem_Click(object sender, EventArgs e) {
      if (!GalaxyMap.bMapSetup) return;
      ShipView sv = new ShipView(PlayerTeam, UpdateAfterClosingShipView);
      sv.ShowDialog(this);
    }
    private void teamToolStripMenuItem_Click(object sender, EventArgs e) {
      if (!GalaxyMap.bMapSetup) return;
      TeamView tv = new TeamView(PlayerTeam);
      tv.ShowDialog(this);
    }
    private void colonyToolStripMenuItem_Click(object sender, EventArgs e) {
      if (!GalaxyMap.bMapSetup) return;
      if (PlayerTeam.CurrentPosition.BaseSize == 0) {
        MessageBox.Show(this, "No colony exists at current location");
        return;
      }
      ColonyView cv = new ColonyView(PlayerTeam);
      cv.Show(this);
    }
    private void racesToolStripMenuItem_Click(object sender, EventArgs e) {
      if (!GalaxyMap.bMapSetup) return;
      RaceView rv = new RaceView();
      rv.Show(this);
    }
    private void UpdateAfterClosingShipView() {
      SetAOButtonsOnGUI(aoSelected);
      glMapView.Invalidate();
    }
    #endregion // View Menu


    #endregion // Menu Code

  }
}

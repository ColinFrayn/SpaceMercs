﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace SpaceMercs.Dialogs {
  partial class ShipView : Form {
    private readonly Team PlayerTeam;
    private bool bLoaded = false;
    private double aspect = 1.0;
    private static Matrix4 perspective;
    private int mx, my;
    private float fShipViewX, fShipViewY, fShipViewZ = Const.MinimumShipViewZ;
    private int irHover = -1, irContextRoom = -1, irSelected = -1;
    private int iStarfieldDL = -1;
    static Matrix4 ortho_projection = Matrix4.CreateOrthographicOffCenter(0, 1, 1, 0, -1, 1);
    private readonly GUIPanel gpSelect;
    private IPanelItem piHoverItem;
    private int iBuildingTexture, iMiscTexture;
    private readonly GUIButton gbRepair, gbFabricate;
    private TextLabel tlHover, tlCash;
    private readonly TextLabel tlHull = new TextLabel("Hull"), tlPower = new TextLabel("Power"), tlHullValue = new TextLabel(), tlPowerValue = new TextLabel();
    private readonly TextLabel tlSel1 = new TextLabel(), tlSel2 = new TextLabel(), tlSel3 = new TextLabel(), tlSel4 = new TextLabel();
    private bool bHoverHull = false, bContextHull = false;
    private readonly Action RefreshCallingWindow = null;

    // Possible icon IDs (must be larger than the number of ShipEquipment)
    public const uint I_Build = 10000;
    public const uint I_Cancel = 10001;
    public const uint I_Salvage = 10002;
    public const uint I_Timer = 10003;
    public const uint I_Disconnect = 10004;
    public const uint I_Connect = 10005;
    public const uint I_None = 10006;

    public ShipView(Team t, Action refreshCallingWindow) {
      PlayerTeam = t;
      InitializeComponent();
      RefreshCallingWindow = refreshCallingWindow;
      fShipViewX = fShipViewY = 0.0f;
      fShipViewZ = PlayerTeam.PlayerShip.Length * 2;
      if (fShipViewZ < Const.MinimumShipViewZ) fShipViewZ = Const.MinimumShipViewZ;
      gpSelect = new GUIPanel(glShipView);
      gbRepair = new GUIButton("Repair", glShipView, RepairShip);
      gbFabricate = new GUIButton("Fabricate", glShipView, FabricateItems);
      SetupUtilityButtons();
    }

    private void SetupUtilityButtons() {
      // "Repair Ship" button
      gbRepair.SetPosition(0.89, 0.35);
      gbRepair.SetSize(0.08, 0.03);
      gbRepair.SetBlend(false);
      if (PlayerTeam.PlayerShip.HullFract < 1.0) gbRepair.Activate();
      else gbRepair.Deactivate();
      if (PlayerTeam.CurrentPosition.PriceModifier > 1.0) gbRepair.Deactivate(); // Not Neutral or better with the owner race
      if ((PlayerTeam.CurrentPosition.Base & (Colony.BaseType.Colony | Colony.BaseType.Metropolis | Colony.BaseType.Military)) == 0) gbRepair.Deactivate(); // Only colonies, metropolis or military bases can repair

      // Fabrication Button
      gbFabricate.SetPosition(0.89, 0.4);
      gbFabricate.SetSize(0.08, 0.03);
      gbFabricate.SetBlend(false);
      gbFabricate.Deactivate();
      if (PlayerTeam.PlayerShip.HasArmoury) gbFabricate.Activate();
      else if (PlayerTeam.PlayerShip.HasWorkshop) gbFabricate.Activate();
      else if (PlayerTeam.PlayerShip.HasMedlab) gbFabricate.Activate();
    }
    private void glShipView_Paint(object sender, PaintEventArgs e) {
      if (!bLoaded) return;

      // Set up default OpenGL rendering parameters
      PrepareScene();

      // Set the correct view location & perspective matrix
      GL.MatrixMode(MatrixMode.Projection);
      GL.LoadMatrix(ref perspective);
      GL.MatrixMode(MatrixMode.Modelview);
      GL.LoadIdentity();

      // Draw the starfield (unmoving)
      if (iStarfieldDL == -1) SetupStarfield();
      GL.CallList(iStarfieldDL);

      // Shift to the correct location
      GL.Translate(-fShipViewX, -fShipViewY, -fShipViewZ);

      // Draw the ship
      PlayerTeam.PlayerShip.DrawSchematic(irHover, iBuildingTexture, bHoverHull);

      // Draw any static GUI elements
      ShowShipGUI();

      // Swap rendered surface to front
      glShipView.SwapBuffers();
    }

    // Keyboard input
    private void glShipView_KeyUp(object sender, KeyEventArgs e) {
      if (e.KeyCode == Keys.L) {
        // TODO: Key handler
      }
      glShipView.Invalidate();
    }
    private void ShipView_KeyDown(object sender, KeyEventArgs e) {
      glShipView.Invalidate();
    }

    // Mouse stuff
    private void glShipView_MouseMove(object sender, MouseEventArgs e) {
      if (e.Button == MouseButtons.Left) {
        float fScale = Const.MouseMoveScale * fShipViewZ / 50.0f;
        if (Control.ModifierKeys == Keys.Control) fScale *= 2.5f;
        else if (Control.ModifierKeys == Keys.Shift) fScale /= 2.5f;
        fShipViewX -= (float)(e.X - mx) * fScale;
        if (fShipViewX < -PlayerTeam.PlayerShip.Length / 1.9f) fShipViewX = -PlayerTeam.PlayerShip.Length / 1.9f;
        if (fShipViewX > PlayerTeam.PlayerShip.Length / 1.9f) fShipViewX = PlayerTeam.PlayerShip.Length / 1.9f;
        fShipViewY += (float)(e.Y - my) * fScale;
        if (fShipViewY < -PlayerTeam.PlayerShip.Width / 1.9f) fShipViewY = -PlayerTeam.PlayerShip.Width / 1.9f;
        if (fShipViewY > PlayerTeam.PlayerShip.Width / 1.9f) fShipViewY = PlayerTeam.PlayerShip.Width / 1.9f;
        glShipView.Invalidate();
      }
      bool bRep = gbRepair.IsHover(mx, my);
      bool bFab = gbFabricate.IsHover(mx, my);
      mx = e.X;
      my = e.Y;
      int rOldHover = irHover;
      IPanelItem piOldItem = piHoverItem;
      CheckHover();
      glShipView.Invalidate();
    }
    private void glShipView_MouseUp(object sender, MouseEventArgs e) {
      // Check R-button released
      if (e.Button == MouseButtons.Right) {
        if (gpSelect.Active) {
          gpSelect.Deactivate();
          int iSelectHover = gpSelect.HoverID;
          // Process GUIPanel selection
          if (iSelectHover >= 0) {
            if (iSelectHover < StaticData.ShipEquipment.Count) {
              if (bContextHull) PlayerTeam.PlayerShip.UpgradeHull(StaticData.ShipEquipment[iSelectHover]);
              else PlayerTeam.PlayerShip.BuildEquipment(irContextRoom, StaticData.ShipEquipment[iSelectHover]);
              RefreshCallingWindow();
            }
            if (iSelectHover == I_Salvage) {
              if (bContextHull) PlayerTeam.PlayerShip.SalvageHull();
              else PlayerTeam.PlayerShip.SalvageRoom(irContextRoom);
              RefreshCallingWindow();
            }
            if (iSelectHover == I_Disconnect) {
              PlayerTeam.PlayerShip.DeactivateRoom(irContextRoom);
              RefreshCallingWindow();
            }
            if (iSelectHover == I_Connect) {
              PlayerTeam.PlayerShip.ActivateRoom(irContextRoom);
              RefreshCallingWindow();
            }
          }
        }
        irContextRoom = -1;
        bContextHull = false;
      }
      if (e.Button == MouseButtons.Left) {
        if (gbRepair.CaptureClick(mx, my)) return;
        if (gbFabricate.CaptureClick(mx, my)) return;
      }
      CheckHover();
      SetupUtilityButtons();
      glShipView.Invalidate();
    }
    private void glShipView_MouseDown(object sender, MouseEventArgs e) {
      mx = e.X;
      my = e.Y;
      if (e.Button == MouseButtons.Right) {
        SetupContextMenu();
      }
      if (e.Button == MouseButtons.Left) {
        SetSelection(irHover);
        irSelected = irHover;
      }
    }
    private void glShipView_DoubleClick(object sender, MouseEventArgs e) {
      if (e.Button == MouseButtons.Left) {
        fShipViewX = fShipViewY = 0.0f;
        fShipViewZ = PlayerTeam.PlayerShip.Length * 2;
        if (fShipViewZ < Const.MinimumShipViewZ) fShipViewZ = Const.MinimumShipViewZ;
        glShipView.Invalidate();
      }
    }
    private void glShipView_MouseWheel(object sender, MouseEventArgs e) {
      float delta = 0.0f;
      if (Control.ModifierKeys == Keys.Control) delta -= e.Delta / 50.0f;
      else if (Control.ModifierKeys == Keys.Shift) delta -= e.Delta / 500.0f;
      else delta -= e.Delta / 150.0f;
      fShipViewZ += delta;
      if (fShipViewZ < Const.MinimumShipViewZ) fShipViewZ = Const.MinimumShipViewZ;
      if (fShipViewZ > Const.MaximumShipViewZ) fShipViewZ = Const.MaximumShipViewZ;
      glShipView.Invalidate();
    }

    // Admin
    private void ShipView_FormClosing(object sender, FormClosingEventArgs e) {
      bLoaded = false;
      if (RefreshCallingWindow != null) RefreshCallingWindow();
    }
    private void ShipView_Load(object sender, EventArgs e) {
      SetupViewport();
      GL.Enable(EnableCap.Texture2D);
      iBuildingTexture = Textures.GetBuildingTexture();
      iMiscTexture = Textures.GetMiscTexture();
      bLoaded = true;
      tlCash = new TextLabel(PlayerTeam.Cash.ToString("F2") + " credits");
      tlCash.SetTextColor(Color.White);
      glShipView.Invalidate();
    }
    private void glShipView_Resize(object sender, EventArgs e) {
      if (!bLoaded) return;
      SetupViewport();
      glShipView.Invalidate();
    }

    // Set up the scene ready for rendering
    private void PrepareScene() {
      glShipView.MakeCurrent();
      GL.ClearColor(Color.Black);
      GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
      GL.CullFace(CullFaceMode.Back);
      GL.ShadeModel(ShadingModel.Smooth);
      GL.Disable(EnableCap.DepthTest);
      GL.Disable(EnableCap.Blend);
      GL.Hint(HintTarget.PerspectiveCorrectionHint, HintMode.Nicest);
      GL.DepthMask(false);
      GL.Disable(EnableCap.Texture2D);
      GL.Disable(EnableCap.Lighting);
    }

    // Setup the OpenGL viewport
    private void SetupViewport() {
      glShipView.MakeCurrent();
      int w = glShipView.Width;
      int h = glShipView.Height;
      aspect = (double)w / (double)h;
      perspective = Matrix4.CreatePerspectiveFieldOfView(Const.MapViewportAngle, (float)aspect, 0.05f, 5000.0f);
      GL.Viewport(0, 0, w, h);
    }

    // Need to trap keypresses of e.g. Alt, Ctrl key alone, not as modifiers
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData) {
      glShipView.Invalidate();
      return base.ProcessCmdKey(ref msg, keyData);
    }

    // Check if we're hovering on a specific room
    private void CheckHover() {
      irHover = -1;
      piHoverItem = null;
      // Check GUIPanel first
      if (gpSelect.Active && gpSelect.HoverItem != null) {
        piHoverItem = gpSelect.HoverItem;
        return;
      }
      // Calculate the position of the mouse pointer
      double mxfract = (double)mx / (double)glShipView.Width;
      double myfract = (double)my / (double)glShipView.Height;
      double mxpos = ((mxfract - 0.5) * (fShipViewZ / 1.86) * aspect) + fShipViewX;
      double mypos = ((0.5 - myfract) * (fShipViewZ / 1.86)) + fShipViewY;
      irHover = PlayerTeam.PlayerShip.CheckHoverRoom(mxpos, mypos, out bHoverHull);
    }

    // Setup a starfield for the background
    private void SetupStarfield() {
      Random rnd = new Random();
      // Create the id for the list
      iStarfieldDL = GL.GenLists(1);

      // Start list
      GL.NewList(iStarfieldDL, ListMode.Compile);

      // Generate a lot of stars
      GL.Begin(BeginMode.Points);
      for (int n = 0; n < Const.StarfieldSize; n++) {
        double col = (1.0 - (Math.Pow(rnd.NextDouble() * 8.0, 0.3333) / 2.0)) * 0.9 + 0.1;
        double x = (rnd.NextDouble() * 140.0) - 70.0;
        double y = (rnd.NextDouble() * 90.0) - 45.0;
        if (rnd.Next(20) == 0) GL.PointSize(3.0f);
        else if (rnd.Next(5) == 0) GL.PointSize(2.0f);
        else GL.PointSize(1.0f);
        GL.Color3(col, col, col);
        GL.Vertex3(x, y, -100.0);
      }
      GL.End();

      // endList
      GL.EndList();
    }

    // Show static GUI elements
    private void ShowShipGUI() {
      GL.MatrixMode(MatrixMode.Projection);
      GL.LoadMatrix(ref ortho_projection);
      GL.MatrixMode(MatrixMode.Modelview);
      GL.LoadIdentity();
      GL.Disable(EnableCap.Lighting);
      GL.Clear(ClearBufferMask.DepthBufferBit);

      // Show the context menu, if it's available
      gpSelect.Display(mx, my);

      // Show hover text
      SetupRoomHoverInfo();
      DrawRoomHoverInfo();

      // Show the cash
      GL.PushMatrix();
      GL.Translate(0.01, 0.0, 0.1);
      GL.Color3(1.0, 1.0, 1.0);
      GL.Scale(0.04 / aspect, 0.04, 0.04);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlCash.UpdateText(PlayerTeam.Cash.ToString("F2") + " credits");
      tlCash.Draw(TextLabel.Alignment.TopLeft);
      GL.PopMatrix();

      DrawHullCondition();
      DrawPowerBar();
      if (irSelected != -1) DisplaySelectionText();

      // Display all buttons
      gbRepair.Display(mx, my);
      gbFabricate.Display(mx, my);
    }

    // Setup a mini window to show details of the current hover room or context menu icon
    private void SetupRoomHoverInfo() {
      if (tlHover == null) {
        tlHover = new TextLabel("...");
        tlHover.SetBorder(1, Color.LightGray);
        tlHover.SetBackgroundColor(Color.Black);
      }
      if (gpSelect.Active) {
        int ID = gpSelect.HoverID;
        if (ID >= 0) {
          if (ID < StaticData.ShipEquipment.Count) {
            ShipEquipment se = StaticData.ShipEquipment[ID];
            tlHover.UpdateTextFromList(se.GetHoverText(PlayerTeam.PlayerShip));
          }
          else {
            if (ID == (int)I_Build) tlHover.UpdateText("Build");
            if (ID == (int)I_Cancel) tlHover.UpdateText("Cancel");
            if (ID == (int)I_Salvage) tlHover.UpdateText("Salvage");
            if (ID == (int)I_Timer) tlHover.UpdateText("Sleep");
            if (ID == (int)I_Disconnect) tlHover.UpdateText("Deactivate");
            if (ID == (int)I_Connect) tlHover.UpdateText("Activate");
          }
          return;
        }
      }

      if (bHoverHull || irHover > -1) {
        ShipEquipment se = bHoverHull ? PlayerTeam.PlayerShip.ArmourType : PlayerTeam.PlayerShip.GetEquipmentByRoomID(irHover);
        if (se == null) {
          if (bHoverHull) tlHover.UpdateText("<No Armour>");
          else tlHover.UpdateText("<Empty>");
          return;
        }

        if (se != null) {
          if (bHoverHull || PlayerTeam.PlayerShip.GetIsRoomActive(irHover)) {
            tlHover.UpdateTextFromList(se.GetHoverText());
          }
          else tlHover.UpdateText(se.Name + " (Deactivated)");
        }
        return;
      }      
    }

    // Draw the hover info when hovering over a room
    private void DrawRoomHoverInfo() {
      if (irHover == -1 && !bHoverHull && (!gpSelect.Active || gpSelect.HoverItem == null)) return; // No label to show
      // Draw the hover text
      double xx = (double)mx / (double)glShipView.Width;
      double yy = (double)my / (double)glShipView.Height;
      double thHeight = 0.04 * tlHover.Lines;
      double thWidth = thHeight * (double)tlHover.Width / (double)tlHover.Height;
      double xSep = 0.01, ySep = 0.01;
      if (xx > 0.5) {
        thWidth = -thWidth;
        xSep = -0.01;
      }
      if (yy < 0.5) {
        thHeight = -thHeight;
        ySep = -0.01;
      }

      // Draw the hover text
      GL.Color3(0.7, 0.7, 0.7);
      GL.PushMatrix();
      if (thWidth < 0.0) GL.Translate(xx + thWidth + xSep, 0.0, 0.3);
      else GL.Translate(xx + xSep, 0.0, 0.3);
      if (thHeight > 0.0) GL.Translate(0.0, yy - ySep, 0.0);
      else GL.Translate(0.0, yy - thHeight - ySep, 0.0);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlHover.Draw(TextLabel.Alignment.BottomLeft, Math.Abs(thWidth), Math.Abs(thHeight));
      GL.PopMatrix();
    }

    // Setup mouse-hover context menu
    private void SetupContextMenu() {
      irContextRoom = -1;
      bContextHull = false;
      gpSelect.Reset();
      gpSelect.PanelX = (double)mx / (double)glShipView.Width + 0.02;
      gpSelect.PanelY = (double)my / (double)glShipView.Height + 0.01;
      if (irHover != -1 || bHoverHull) {
        irContextRoom = irHover;
        bContextHull = bHoverHull;
        ShipEquipment seHover = bHoverHull ? PlayerTeam.PlayerShip.ArmourType : PlayerTeam.PlayerShip.GetEquipmentByRoomID(irContextRoom);
        if (seHover == null) {
          if (PlayerTeam.CurrentPosition.BaseSize > 0) {
            GUIPanel buildingPanel = GenerateBuildingList();
            Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.Build);
            gpSelect.InsertIcon(I_Build, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, true, buildingPanel);
          }
        }
        else {
          if (PlayerTeam.CurrentPosition.BaseSize > 0) {
            Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.Salvage);
            gpSelect.InsertIcon(I_Salvage, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, true, null);
          }
          if (!bHoverHull && PlayerTeam.PlayerShip.GetCanDeactivateRoom(irContextRoom)) {
            Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.Disconnect);
            gpSelect.InsertIcon(I_Disconnect, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, true, null);
          }
          else if (!bHoverHull && !PlayerTeam.PlayerShip.GetIsRoomActive(irContextRoom)) {
            Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.Connect);
            gpSelect.InsertIcon(I_Connect, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, true, null);
          }
        }
        gpSelect.Activate();
      }
      glShipView.Invalidate();
    }

    // Generate a building icon list for the sub-panel when building a new room
    private GUIPanel GenerateBuildingList() {
      if (!bHoverHull && (irContextRoom < 0 || irContextRoom > PlayerTeam.PlayerShip.Type.Rooms.Count)) return null;
      ShipRoomDesign rd = bHoverHull ? null : PlayerTeam.PlayerShip.Type.Rooms[irContextRoom];
      ShipEquipment.RoomSize roomSize = bHoverHull ? ShipEquipment.RoomSize.Armour : rd.Size;
      int count = 0;
      GUIPanel gp = new GUIPanel(glShipView);
      List<int> lIDs = Enumerable.Range(0, StaticData.ShipEquipment.Count).ToList<int>();
      lIDs.Sort((a, b) => StaticData.ShipEquipment[a].Cost.CompareTo(StaticData.ShipEquipment[b].Cost));
      foreach (int eno in lIDs) {
        ShipEquipment se = StaticData.ShipEquipment[eno];
        // Can we build this at the current location?
        if ((se.Available & PlayerTeam.CurrentPosition.Base) == 0) continue;
        if (se.RequiredRace != null && PlayerTeam.CurrentPosition.GetSystem().Owner != se.RequiredRace) continue; // Not the correct race
        if (se.RequiredRace != null && PlayerTeam.CurrentPosition.PriceModifier >= 1.0) continue; // Correct race, but player team is not at least friendly

        // Is it the right size?
        if (se.Size != roomSize) continue;

        // Can we afford it?
        bool bAfford = true;
        if (PlayerTeam.PlayerShip.CostToBuildEquipment(se) > PlayerTeam.Cash) bAfford = false;

        // Insert this icon & add to the tally
        Tuple<double, double> tp = Textures.GetTexCoords(se);
        gp.InsertIcon((uint)eno, iBuildingTexture, tp.Item1, tp.Item2, Textures.BuildingTextureWidth, Textures.BuildingTextureHeight, bAfford, null);
        count++;
      }
      if (count == 0) {
        Tuple<double, double> tp = Textures.GetTexCoords(Textures.MiscTexture.None);
        gp.InsertIcon(I_None, iMiscTexture, tp.Item1, tp.Item2, Textures.MiscTextureWidth, Textures.MiscTextureHeight, false, null);
      }
      return gp;
    }

    // Condition bars
    private void DrawHullCondition() {
      // Show the hull condition
      GL.Disable(EnableCap.Texture2D);
      GL.Enable(EnableCap.Blend);
      double dFract = PlayerTeam.PlayerShip.HullFract;
      GL.PushMatrix();
      GL.Translate(0.79, 0.01, 0.1);
      GL.Scale(0.2, 0.2, 1.0);
      GL.Begin(BeginMode.Quads);
      GL.Color3(0.6, 0.0, 0.0);
      GL.Vertex3(0.0, 0.0, 0.0);
      GL.Vertex3(0.0, 0.1, 0.0);
      GL.Color3(1.0, 0.5, 0.0);
      GL.Vertex3(0.3, 0.1, 0.0);
      GL.Vertex3(0.3, 0.0, 0.0);
      //
      GL.Color3(1.0, 0.5, 0.0);
      GL.Vertex3(0.3, 0.0, 0.0);
      GL.Vertex3(0.3, 0.1, 0.0);
      GL.Color3(1.0, 1.0, 0.0);
      GL.Vertex3(0.5, 0.1, 0.0);
      GL.Vertex3(0.5, 0.0, 0.0);
      //
      GL.Color3(1.0, 1.0, 0.0);
      GL.Vertex3(0.5, 0.0, 0.0);
      GL.Vertex3(0.5, 0.1, 0.0);
      GL.Color3(0.0, 1.0, 0.0);
      GL.Vertex3(0.8, 0.1, 0.0);
      GL.Vertex3(0.8, 0.0, 0.0);
      //
      GL.Color3(0.0, 1.0, 0.0);
      GL.Vertex3(0.8, 0.0, 0.0);
      GL.Vertex3(0.8, 0.1, 0.0);
      GL.Color3(0.0, 0.0, 0.7);
      GL.Vertex3(1.0, 0.1, 0.0);
      GL.Vertex3(1.0, 0.0, 0.0);
      // Remove the damage
      GL.Color3(0.0, 0.0, 0.0);
      GL.Vertex3(dFract, 0.0, 0.0);
      GL.Vertex3(1.0, 0.0, 0.0);
      GL.Vertex3(1.0, 0.1, 0.0);
      GL.Vertex3(dFract, 0.1, 0.0);
      GL.End();

      // Now draw the frame
      GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Line);
      GL.Color3(1.0, 1.0, 1.0);
      GL.Begin(BeginMode.Quads);
      GL.Vertex3(0.0, 0.0, 0.1);
      GL.Vertex3(1.0, 0.0, 0.1);
      GL.Vertex3(1.0, 0.1, 0.1);
      GL.Vertex3(0.0, 0.1, 0.1);
      GL.End();
      GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Fill);
      GL.PopMatrix();

      // Show the label
      GL.PushMatrix();
      GL.Translate(0.78, 0.0, 0.1);
      GL.Color3(1.0, 1.0, 1.0);
      GL.Scale(0.04 / aspect, 0.04, 0.04);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlHull.Draw(TextLabel.Alignment.TopRight);
      GL.PopMatrix();

      // Show the value
      string strHull = PlayerTeam.PlayerShip.Hull.ToString("0.#") + " / " + PlayerTeam.PlayerShip.Type.MaxHull.ToString("0.#");
      tlHullValue.UpdateText(strHull);
      GL.PushMatrix();
      GL.Translate(0.89, 0.03, 0.1);
      GL.Color3(1.0, 1.0, 1.0);
      GL.Scale(0.03 / aspect, 0.03, 0.03);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlHullValue.Draw(TextLabel.Alignment.TopMiddle);
      GL.PopMatrix();
    }
    private void DrawPowerBar() {
      // Show the power bar
      GL.Disable(EnableCap.Texture2D);
      double dFract = 0.0;
      GL.PushMatrix();
      GL.Translate(0.79, 0.12, 0.1);
      GL.Scale(0.2, 0.2, 1.0);
      int pg = PlayerTeam.PlayerShip.PowerGeneration;
      int pc = PlayerTeam.PlayerShip.PowerConsumption;
      if (pg > 0) {
        dFract = (double)pc / (double)pg;
        if (dFract < 1.0) {
          GL.Color3(0.0, 1.0, 0.0);
          GL.Begin(BeginMode.Quads);
          GL.Vertex3(0.0, 0.0, 0.0);
          GL.Vertex3(dFract, 0.0, 0.0);
          GL.Vertex3(dFract, 0.1, 0.0);
          GL.Vertex3(0.0, 0.1, 0.0);
          GL.End();
        }
        else {
          GL.Color3(0.0, 1.0, 0.0);
          GL.Begin(BeginMode.Quads);
          GL.Vertex3(0.0, 0.0, 0.0);
          GL.Vertex3(1 / dFract, 0.0, 0.0);
          GL.Vertex3(1 / dFract, 0.1, 0.0);
          GL.Vertex3(0.0, 0.1, 0.0);
          GL.Color3(1.0, 0.0, 0.0);
          GL.Vertex3(1 / dFract, 0.0, 0.0);
          GL.Vertex3(1.0, 0.0, 0.0);
          GL.Vertex3(1.0, 0.1, 0.0);
          GL.Vertex3(1 / dFract, 0.1, 0.0);
          GL.End();
        }
      }
      else {
        GL.Color3(1.0, 0.0, 0.0);
        GL.Begin(BeginMode.Quads);
        GL.Vertex3(0.0, 0.0, 0.0);
        GL.Vertex3(1.0, 0.0, 0.0);
        GL.Vertex3(1.0, 0.1, 0.0);
        GL.Vertex3(0.0, 0.1, 0.0);
        GL.End();
      }

      // Now draw the frame
      GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Line);
      GL.Color3(1.0, 1.0, 1.0);
      GL.Begin(BeginMode.Quads);
      GL.Vertex3(0.0, 0.0, 0.1);
      GL.Vertex3(1.0, 0.0, 0.1);
      GL.Vertex3(1.0, 0.1, 0.1);
      GL.Vertex3(0.0, 0.1, 0.1);
      GL.End();
      GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Fill);
      GL.PopMatrix();

      // Show the label
      GL.PushMatrix();
      GL.Translate(0.78, 0.11, 0.1);
      GL.Color3(1.0, 1.0, 1.0);
      GL.Scale(0.04 / aspect, 0.04, 0.04);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlPower.Draw(TextLabel.Alignment.TopRight);
      GL.PopMatrix();

      // Show the value
      string strPower = "Using " + pc + " / " + pg;
      tlPowerValue.UpdateText(strPower);
      GL.PushMatrix();
      GL.Translate(0.89, 0.14, 0.1);
      GL.Color3(1.0, 1.0, 1.0);
      GL.Scale(0.03 / aspect, 0.03, 0.03);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlPowerValue.Draw(TextLabel.Alignment.TopMiddle);
      GL.PopMatrix();

    }

    // Display the text labels required for the GUI
    private void DisplaySelectionText() {
      double dTLScale = 0.035;
      double dXMargin = 0.01;
      double dYStart = 0.83;
      double dYGap = 0.0325;
      // Display the text details of the selected object
      GL.PushMatrix();
      GL.Translate(dXMargin, dYStart, 0.1);
      GL.Scale(dTLScale / aspect, dTLScale, dTLScale);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlSel1.Draw(TextLabel.Alignment.CentreLeft);
      GL.PopMatrix();
      GL.PushMatrix();
      GL.Translate(dXMargin, dYStart + dYGap, 0.1);
      GL.Scale(dTLScale / aspect, dTLScale, dTLScale);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlSel2.Draw(TextLabel.Alignment.CentreLeft);
      GL.PopMatrix();
      GL.PushMatrix();
      GL.Translate(dXMargin, dYStart + dYGap * 2.0, 0.1);
      GL.Scale(dTLScale / aspect, dTLScale, dTLScale);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlSel3.Draw(TextLabel.Alignment.CentreLeft);
      GL.PopMatrix();
      GL.PushMatrix();
      GL.Translate(dXMargin, dYStart + dYGap * 3.0, 0.1);
      GL.Scale(dTLScale / aspect, dTLScale, dTLScale);
      GL.Rotate(180.0, Vector3d.UnitX);
      tlSel4.Draw(TextLabel.Alignment.CentreLeft);
      GL.PopMatrix();
    }

    // Ship function buttons
    public void RepairShip() {
      double cost = PlayerTeam.PlayerShip.CalculateRepairCost();
      if (cost == 0.0) return;
      cost = Math.Round(cost, 2);
      if (MessageBox.Show("Repair would cost " + cost + " credits. Proceed?", "Really Repair?", MessageBoxButtons.YesNo) == DialogResult.No) return;
      PlayerTeam.Cash -= cost;
      PlayerTeam.PlayerShip.RepairHull();
      gbRepair.Deactivate();
    }
    public void FabricateItems() {
      FabricateItems fi = new FabricateItems(PlayerTeam);
      fi.ShowDialog(this);
    }
    public void WaitForEvents() {
      MessageBox.Show("Wait not yet implemented");
      // TODO
    }

    // Setup the details for the selected room
    private void SetSelection(int iRoomID) {
      ShipEquipment se = PlayerTeam.PlayerShip.GetEquipmentByRoomID(iRoomID);
      if (se == null) {
        tlSel1.UpdateText("<Empty>");
        tlSel2.bEnabled = false;
        tlSel3.bEnabled = false;
        tlSel4.bEnabled = false;
        return;
      }

      tlSel1.UpdateText(se.Name);
      if (se is ShipArmour) {
        tlSel2.UpdateText("Armour : " + ((ShipArmour)se).BaseArmour + "%");
        if (se.Defence > 0) tlSel3.UpdateText("Defence Bonus : " + se.Defence);
        else tlSel3.bEnabled = false;
        if (((ShipArmour)se).HealRate > 0) tlSel4.UpdateText("Heal Rate : " + ((ShipArmour)se).HealRate);
        else tlSel4.bEnabled = false;
      }
      else if (se is ShipEngine) {
        if (((ShipEngine)se).Range >= Const.LightYear) tlSel2.UpdateText("Range : " + Math.Round(((ShipEngine)se).Range / Const.LightYear,1) + "ly");
        else tlSel2.UpdateText("Range : System");
        tlSel3.UpdateText("Speed : " + Math.Round(((ShipEngine)se).Speed / Const.SpeedOfLight, 1) + "c");
        tlSel4.UpdateText("Accel : " + Math.Round(((ShipEngine)se).Accel/10.0,1) + "g"); // Yeah I know g =~9.8, but whatever
      }
      else if (se is ShipEquipment) {
        if (se.Generate > 0) tlSel2.UpdateText("Generate : " + se.Generate);
        else tlSel2.UpdateText("Power : " + se.Power);   
        if (se.Attack > 0) tlSel3.UpdateText("Attack Bonus : " + se.Attack);
        else if (se.Defence > 0) tlSel3.UpdateText("Defence Bonus : " + se.Defence);
        else tlSel3.bEnabled = false;
        string strDesc = "";
        if (se.Capacity > 0) strDesc = "Support : " + se.Capacity;
        else if (se.Medlab) strDesc += "Medbay";
        else if (se.Armoury) strDesc += "Armoury";
        else if (se.Workshop) strDesc += "Workshop";
        else tlSel4.bEnabled = false;
        if (!String.IsNullOrEmpty(strDesc)) tlSel4.UpdateText(strDesc);
      }
      else if (se is ShipWeapon) {
        tlSel2.UpdateText("Power : " + se.Power);
        tlSel3.UpdateText("Attack Bonus : " + se.Attack);
        tlSel4.bEnabled = false;
      }
      else {
        tlSel2.UpdateText("Unknown Room Type : " + se.GetType());
        tlSel3.bEnabled = false;
        tlSel4.bEnabled = false;
      }
    }

  }
}
